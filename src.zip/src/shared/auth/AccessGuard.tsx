import {type FC} from 'react';
import {Navigate} from 'react-router-dom';
import {useUnit} from "effector-react/effector-react.mjs";
import {authModel} from "@/store/auth.ts";
import {UserPermission} from "@/api/users/models.ts";


export function withAccess(ViewComponent: FC, access: UserPermission[]) {
    const RolesForkComponent: FC = () => {
        const {currentUser} = useUnit(authModel);

        const hasAccess = access.some((permission) => currentUser.permissions.includes(permission));

        if (!hasAccess) {
            return <Navigate to="/access-denied" replace/>;
        }

        return <ViewComponent/>;
    };

    return RolesForkComponent;
}