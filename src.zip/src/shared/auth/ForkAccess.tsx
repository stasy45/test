import {type FC, type ReactElement} from 'react';
import {Navigate} from 'react-router-dom';
import {useUnit} from 'effector-react';

import {authModel} from '@/store/auth.ts';

import type {UserPermission} from '@/api/users/models.ts';

export function forkAccess(match: Partial<Record<UserPermission, ReactElement>>) {
    const RolesForkComponent: FC = () => {
        const {currentUser} = useUnit(authModel);

        const matchedPermission = currentUser.permissions.find((permission) => match[permission]);
        const jsxElement = (matchedPermission ? match[matchedPermission] : undefined) ?? match['*'];

        if (!jsxElement) {
            return <Navigate to="/access-denied" replace/>;
        }

        return jsxElement;
    };

    return RolesForkComponent;
}