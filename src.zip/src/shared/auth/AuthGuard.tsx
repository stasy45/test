import {type ReactNode} from 'react';
import {useUnit} from 'effector-react';

import {TransitionSwitch} from '@/components';
import {authModel} from '@/store/auth.ts';
import {StateWidget} from '@/widgets';


export const AuthGuard = ({children}: { children: ReactNode }) => {
    const {status, retrySession, isAuthLoading} = useUnit(authModel);

    if (status === 'unknown') {
        return <TransitionSwitch isLoading children={children}/>;
    }


    if (status === 'error') {
        return (
            <StateWidget
                code={401}
                title="Не удалось проверить сессию"
                button={{
                    variant: "primary",
                    text: "Попробовать ещё раз",
                    icon: "refresh",
                    onClick: retrySession,
                    isLoading: isAuthLoading
                }}
            />
        );
    }

    if (status === 'authenticated') {
        return <>{children}</>;
    }

    // status === 'unauthenticated': редирект на Keycloak уже запущен
    return <TransitionSwitch isLoading children={children}/>;
};