import {Slide, ToastContainer} from 'react-toastify';


export const NotificationsContainer = () => (
    <ToastContainer
        position="top-right"
        style={{width: '300px'}}
        pauseOnFocusLoss={false}
        transition={Slide}
        autoClose={5000}
        newestOnTop
        icon={false}
        closeButton={false}
        hideProgressBar
        pauseOnHover
        draggable
    />
)