import {memo} from 'react';
import {Alert} from '@/components';
import {ToastTemplateProps} from './types';

import './notifications.scss';
import {ICON_BY_STATUS, TYPOGRAPHY_COLOR_BY_STATUS} from "@/utils/maps.ts";


export const ToastTemplate = memo(
    ({type, title, message}: ToastTemplateProps) => (
        <Alert
            variant={TYPOGRAPHY_COLOR_BY_STATUS[type]}
            iconName={ICON_BY_STATUS[type]}
            text={title}
            description={message}
        />
    ),
);

ToastTemplate.displayName = 'ToastTemplate';