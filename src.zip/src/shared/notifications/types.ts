import {ReactNode} from 'react';
import {ToastOptions} from 'react-toastify';
import {StatusType} from "@/utils/api-models.ts";


export interface ShowNotifyOptions
    extends Pick<ToastOptions, 'pauseOnFocusLoss'> {
    type?: StatusType;
    title: ReactNode;
    message?: ReactNode;
}

export interface ToastTemplateProps {
    type: StatusType;
    title: ReactNode;
    message?: ReactNode;
}