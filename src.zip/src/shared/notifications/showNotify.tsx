import {toast, Id} from 'react-toastify';
import {ToastTemplate} from './ToastTemplate';
import {ShowNotifyOptions} from './types';


export function showNotify(options: ShowNotifyOptions): Id {
    const {
        type = 'success',
        title,
        message,
        ...rest
    } = options;

    return toast(
        <ToastTemplate
            type={type}
            title={title}
            message={message}
        />,
        {
            className: `toast toast--${type}`,
            ...rest,
        },
    );
}

export const closeToast = toast.dismiss;
export {Slide} from 'react-toastify';