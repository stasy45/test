import {mockEndpoints, type MockEndpointKey} from './scenarios/registry';
import type {ScenarioSelection} from './handlers';

export type ApiSource = 'backend' | 'msw';

const API_SOURCE_STORAGE_KEY = 'dev-mode:api-source';
const SCENARIOS_STORAGE_KEY = 'dev-mode:scenarios';

export function readPersistedApiSource(): ApiSource {
    try {
        return localStorage.getItem(API_SOURCE_STORAGE_KEY) === 'msw' ? 'msw' : 'backend';
    } catch {
        return 'backend';
    }
}

function buildDefaultSelection(): ScenarioSelection {
    return mockEndpoints.reduce((selection, endpoint) => {
        selection[endpoint.key as MockEndpointKey] = endpoint.defaultScenarioId;
        return selection;
    }, {} as ScenarioSelection);
}

export function readPersistedSelection(): ScenarioSelection {
    const defaults = buildDefaultSelection();

    try {
        const raw = localStorage.getItem(SCENARIOS_STORAGE_KEY);

        if (!raw) {
            return defaults;
        }

        const persisted = JSON.parse(raw) as Partial<Record<MockEndpointKey, unknown>>;

        return mockEndpoints.reduce((selection, endpoint) => {
            const key = endpoint.key as MockEndpointKey;
            const persistedScenarioId = persisted[key];
            const validScenario = endpoint.scenarios.find(
                (scenario) => scenario.id === persistedScenarioId,
            );

            selection[key] = validScenario?.id ?? endpoint.defaultScenarioId;

            return selection;
        }, {} as ScenarioSelection);
    } catch {
        return defaults;
    }
}

export function persistApiSource(apiSource: ApiSource): void {
    try {
        localStorage.setItem(API_SOURCE_STORAGE_KEY, apiSource);
    } catch {
        // localStorage может быть недоступен.
    }
}

export function persistSelection(selection: ScenarioSelection): void {
    try {
        localStorage.setItem(SCENARIOS_STORAGE_KEY, JSON.stringify(selection));
    } catch {
        // localStorage может быть недоступен.
    }
}
