import {setupWorker} from 'msw/browser';

import {buildMockHandlers, type ScenarioSelection} from './handlers';
import {readPersistedApiSource, readPersistedSelection, type ApiSource} from './persistence';

export type {ApiSource} from './persistence';

const worker = setupWorker();
let isWorkerStarted = false;
let syncVersion = 0;

async function ensureWorkerStarted(): Promise<void> {
    if (isWorkerStarted) {
        return;
    }

    await worker.start({
        onUnhandledRequest: 'bypass',
        quiet: true,
    });

    isWorkerStarted = true;
}

/**
 * Синхронизирует MSW с текущим состоянием dev-виджета.
 *
 * Последовательные изменения источника/сценариев могут запускать несколько
 * асинхронных синхронизаций одновременно. Версия гарантирует, что устаревший
 * вызов не перезапишет handlers результатом нового состояния.
 */
export async function syncMockWorker(
    apiSource: ApiSource,
    selection: ScenarioSelection,
): Promise<boolean> {
    if (!import.meta.env.DEV) {
        return false;
    }

    const currentVersion = ++syncVersion;

    await ensureWorkerStarted();

    if (currentVersion !== syncVersion) {
        return false;
    }

    worker.resetHandlers();

    if (apiSource === 'msw') {
        worker.use(...buildMockHandlers(selection));
    }

    return true;
}

/**
 * Восстанавливает сохранённое состояние MSW до первого запроса приложения.
 * Вызывается из bootstrap ДО appStarted().
 */
export async function ensureMockWorkerReady(): Promise<void> {
    if (!import.meta.env.DEV || readPersistedApiSource() !== 'msw') {
        return;
    }

    await syncMockWorker('msw', readPersistedSelection());
}
