import {createScenario} from './createScenario';
import {ServerError} from "@/utils/api-models.ts";
import {Payment} from "@/api/students/models.ts";


const basePayment: Payment = {
    contract: 'g123',
    steps: [
        {
            checkURL: '/Курс молодого бойца.pdf',
            semester: 1,
            course: 1,
            dueDate: '12.01.2028',
            amount: 40000,
        },
        {
            checkURL: '/Курс молодого бойца.pdf',
            semester: 1,
            course: 1,
            dueDate: '12.01.2027',
            amount: 10000,
        },
        {
            semester: 1,
            course: 1,
            dueDate: '12.01.2028',
            amount: 50000,
        },
    ],
};

export const paymentStepsScenarios = [
    createScenario<Payment>({
        id: 'default',
        label: 'Несколько этапов',
        status: 200,
        body: basePayment,
    }),

    createScenario<Payment>({
        id: 'no-steps',
        label: 'Нет этапов',
        status: 200,
        body: {...basePayment, steps: []},
    }),

    createScenario<ServerError>({
        id: 'unauthorized',
        label: '401',
        status: 401,
        body: {
            status: 401,
            message: 'Требуется авторизация'
        },
    }),

    createScenario<ServerError>({
        id: 'forbidden',
        label: '403',
        status: 403,
        body: {
            status: 403,
            message: 'Недостаточно прав'
        },
    }),

    createScenario<ServerError>({
        id: 'server-error',
        label: '500',
        status: 500,
        body: {
            status: 500,
            message: 'Внутренняя ошибка сервера'
        },
    }),
] as const;
