import {createScenario} from './createScenario';
import type {ApplicationInfo} from '@/api/application/models.ts';
import {ServerError} from "@/utils/api-models.ts";


export const applicationInfoScenarios = [
    createScenario<ApplicationInfo>({
        id: 'true',
        label: 'Все true',
        status: 200,
        body: {income: true, isPassportActual: true},
    }),

    createScenario<ApplicationInfo>({
        id: 'false',
        label: 'Все false',
        status: 200,
        body: {income: false, isPassportActual: false},
    }),

    createScenario<ServerError>({
        id: 'unauthorized',
        label: '401',
        status: 401,
        body: {
            status: 401,
            message: 'Требуется авторизация'
        },
    }),

    createScenario<ServerError>({
        id: 'server-error',
        label: '500',
        status: 500,
        body: {
            status: 500,
            message: 'Внутренняя ошибка сервера'
        },
    }),
] as const;
