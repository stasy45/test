import {createScenario} from './createScenario';
import {ServerError} from "@/utils/api-models.ts";
import {ProfileInfo} from "@/api/students/models.ts";


const baseProfile: ProfileInfo = {
    birthday: '12.02.2002',
    email: 'ivanov@example.com',
    phone: '+79179502286',
    additionalStatuses: [
        'Сирота',
        'Инвалид'
    ],
    residence: {
        contract: '№ 123/2025',
        settlementDate: '02.02.2002',
        // ejectmentDate: '02.02.2002',
    },
    passport: {
        number: '5522',
        serialNumber: '123456',
        issued: 'ГУ МВД России по г. Москве',
        issuedDate: '02.02.2002',
    },
    bypass: {
        year: 2026,
        points: [
            {
                name: 'Библиотека',
                status: {type: 'warning'},
                description: 'Требуется подтвердить отсутствие задолженности',
            },
            {name: 'Бухгалтерия', status: {type: 'success'}},
        ],
    },
    education: [
        {
            studentId: "3839",
            name: 'Московский государственный университет',
            studentCategory: 'Студент',
            direction: '09.03.04 Программная инженерия',
            group: 'ПИ-21-1',
            course: 4,
            financial: 'Целевое',
            organization: 'ООО "Технологии будущего"',
            scholarship: {type: 'Государственная академическая стипендия', amount: 3200},
            averageScore: 4.7,
            absences: 2,
            averageSessionScore: 4.8,
        },
        {
            studentId: "5586",
            name: 'Московский государственный университет',
            studentCategory: 'Студент',
            direction: '09.03.04 Программная инженерия',
            group: 'ПИ-21-1',
            course: 4,
            financial: 'Договор',
            averageScore: 4.7,
            absences: 2,
            averageSessionScore: 4.8,
        },
        {
            studentId: "5586",
            name: 'Московский государственный университет',
            studentCategory: 'Студент',
            direction: '09.03.04 Программная инженерия',
            group: 'ПИ-21-1',
            course: 4,
            financial: 'Договор',
            averageScore: 4.7,
            absences: 2,
            averageSessionScore: 4.8,
        },
    ],
};

export const studentProfileScenarios = [
    createScenario<ProfileInfo>({
        id: 'full-info',
        label: 'Все поля',
        status: 200,
        body: baseProfile,
    }),

    createScenario<ProfileInfo>({
        id: 'no-family-residence-bypass',
        label: 'Без семьи, без проживания, без обходного листа',
        status: 200,
        body: {...baseProfile, residence: undefined, bypass: undefined},
    }),

    createScenario<ServerError>({
        id: 'unauthorized',
        label: '401',
        status: 401,
        body: {
            status: 401,
            message: 'Требуется авторизация'
        },
    }),

    createScenario<ServerError>({
        id: 'forbidden',
        label: '403',
        status: 403,
        body: {
            status: 403,
            message: 'Недостаточно прав'
        },
    }),

    createScenario<ServerError>({
        id: 'server-error',
        label: '500',
        status: 500,
        body: {
            status: 500,
            message: 'Внутренняя ошибка сервера'
        },
    }),
] as const;
