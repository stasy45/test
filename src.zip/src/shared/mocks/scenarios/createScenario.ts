export type MockHttpStatus = 200 | 400 | 401 | 403 | 404 | 500;

export interface MockScenario<TBody> {
    /** Уникальный идентификатор сценария в рамках одного эндпоинта */
    id: string;
    /** Человекочитаемое название, отображается в dev-попапе */
    label: string;
    /** HTTP статус-код, с которым будет отдан ответ */
    status: MockHttpStatus;
    /** Искусственная задержка ответа, мс — удобно проверять скелетоны/лоадеры */
    delay?: number;
    /** Тело ответа. Функция вызывается лениво, в момент обработки запроса */
    body: TBody | (() => TBody);
}

/**
 * Тонкая типобезопасная обёртка: не делает ничего кроме проверки формы объекта,
 * но даёт нормальный автокомплит и инференс TBody в местах создания сценариев.
 */
export function createScenario<TBody>(scenario: MockScenario<TBody>): MockScenario<TBody> {
    return scenario;
}

export function resolveScenarioBody<TBody>(scenario: MockScenario<TBody>): TBody {
    return typeof scenario.body === 'function' ? (scenario.body as () => TBody)() : scenario.body;
}
