import {createScenario} from './createScenario';
import {ServerError} from "@/utils/api-models.ts";
import {Session} from "@/api/students/models.ts";


const baseSession: Session[] = [
    {
        year: 2026,
        course: 2,
        semester: [
            {
                count: 1,
                subjects: [
                    {
                        date: "12.02.2026",
                        name: "Jeff Wehner",
                        type: "Зачёт",
                        grade: {
                            type: "error",
                            message: "Незачёт",
                        },
                    },
                    {
                        date: "12.02.2026",
                        name: "Marcia Lakin",
                        type: "Зачёт",
                        grade: {
                            type: "success",
                            message: "Зачёт",
                        },
                    },
                ],
            },
        ],
    },
];

export const sessionScenarios = [
    createScenario<Session[]>({
        id: 'default',
        label: 'Несколько результатов',
        status: 200,
        body: baseSession,
    }),

    createScenario<Session[]>({
        id: 'empty',
        label: 'Результатов нет',
        status: 200,
        body: [],
    }),

    createScenario<ServerError>({
        id: 'unauthorized',
        label: '401',
        status: 401,
        body: {
            status: 401,
            message: 'Требуется авторизация'
        },
    }),

    createScenario<ServerError>({
        id: 'forbidden',
        label: '403',
        status: 403,
        body: {
            status: 403,
            message: 'Недостаточно прав'
        },
    }),

    createScenario<ServerError>({
        id: 'server-error',
        label: '500',
        status: 500,
        body: {
            status: 500,
            message: 'Внутренняя ошибка сервера'
        },
    }),
] as const;
