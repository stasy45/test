import type {CurrentUser} from '@/api/users/models.ts';
import {createScenario} from './createScenario';
import {ServerError} from "@/utils/api-models.ts";


const baseUser: CurrentUser = {
    subject: '018f0c5c-9c2d-7a1e-b460-36f8b8230c50',
    fio: 'Иванов Иван Иванович',
    initials: 'ИИ',
    photo: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAFCAYAAACNbyblAAAAHElEQVQI12P4//8/w38GIAXDIBKE0DHxgljNBAAO9TXL0Y4OHwAAAABJRU5ErkJggg==',
    snils: "175-660-634 93",
    permissions: ['ACCESS_STUDENT_PROFILE'],
};

export const currentUserScenarios = [
    createScenario<CurrentUser>({
        id: 'full-info',
        label: 'Полная информация',
        status: 200,
        body: baseUser,
    }),

    createScenario<CurrentUser>({
        id: 'no-avatar-permissions',
        label: 'Без аватарки',
        status: 200,
        body: {...baseUser, photo: undefined},
    }),

    createScenario<ServerError>({
        id: 'unauthorized',
        label: '401',
        status: 401,
        body: {
            status: 401,
            message: 'Требуется авторизация'
        },
    }),

    createScenario<ServerError>({
        id: 'server-error',
        label: '500',
        status: 500,
        body: {
            status: 500,
            message: 'Внутренняя ошибка сервера'
        },
    }),
] as const;
