import type {MockScenario} from './createScenario';
import {applicationInfoScenarios} from './applicationInfo.scenarios';
import {currentUserScenarios} from './currentUser.scenarios';
import {studentProfileScenarios} from './studentProfile.scenarios.ts';
import {paymentStepsScenarios} from "./paymentSteps.scenarios.ts";
import {academicPerformanceScenarios} from "@/shared/mocks/scenarios/academicPerformance.scenarios.ts";
import {sessionScenarios} from "@/shared/mocks/scenarios/session.scenarios.ts";


export type MockMethod = 'get' | 'post' | 'put' | 'patch' | 'delete';

export interface MockEndpointConfig {
    /** Ключ используется в effector-сторе выбора сценариев и в конфиге страниц */
    key: string;
    method: MockMethod;
    url: string;
    /** Название эндпоинта для UI попапа */
    label: string;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any -- реестр намеренно гетерогенный по TBody
    scenarios: readonly MockScenario<any>[];
    defaultScenarioId: string;
}

/**
 * Хелпер для описания одного эндпоинта в реестре.
 *
 * Параметр `scenarios` намеренно типизирован как `MockScenario<any>[]` —
 * это "стирает" конкретный TBody каждого набора сценариев, чтобы при переборе
 * mockEndpoints TypeScript не пытался схлопнуть все наборы сценариев в единый
 * union и не путал ApplicationInfo с ProfileInfo. При этом `key` остаётся
 * generic-параметром, поэтому его литеральный тип не теряется — именно на нём
 * строится MockEndpointKey ниже.
 */
function defineEndpoint<TKey extends string>(config: {
    key: TKey;
    method: MockMethod;
    url: string;
    label: string;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    scenarios: readonly MockScenario<any>[];
    defaultScenarioId: string;
}) {
    return config;
}

/**
 * Единая точка регистрации мок-эндпоинтов.
 * Чтобы добавить новый эндпоинт: опишите его сценарии в соседнем файле
 * *.scenarios.ts и добавьте запись сюда — виджет и MSW handlers подхватят её сами.
 */
export const mockEndpoints = [
    defineEndpoint({
        key: 'getApplicationInfo',
        method: 'get',
        url: '/api/application',
        label: 'Настройки приложения',
        scenarios: applicationInfoScenarios,
        defaultScenarioId: 'false',
    }),
    defineEndpoint({
        key: 'getCurrentUser',
        method: 'get',
        url: '/api/users/me',
        label: 'Информация об аккаунте',
        scenarios: currentUserScenarios,
        defaultScenarioId: 'full-info',
    }),
    defineEndpoint({
        key: 'getStudentProfile',
        method: 'get',
        url: '/api/students/profile/me',
        label: 'Профиль студента',
        scenarios: studentProfileScenarios,
        defaultScenarioId: 'full-info',
    }),
    defineEndpoint({
        key: 'getPaymentSteps',
        method: 'get',
        url: '/api/students/payments',
        label: 'Этапы договора',
        scenarios: paymentStepsScenarios,
        defaultScenarioId: 'default',
    }),
    defineEndpoint({
        key: 'getAcademicPerformance',
        method: 'get',
        url: '/api/students/academic-performance',
        label: 'Успеваемость',
        scenarios: academicPerformanceScenarios,
        defaultScenarioId: 'default',
    }),
    defineEndpoint({
        key: 'getSession',
        method: 'get',
        url: '/api/students/session-result',
        label: 'Сессия',
        scenarios: sessionScenarios,
        defaultScenarioId: 'default',
    }),
] as const;

export type MockEndpointKey = (typeof mockEndpoints)[number]['key'];

export function getMockEndpoint(key: MockEndpointKey): MockEndpointConfig {
    const endpoint = mockEndpoints.find((item) => item.key === key);

    if (!endpoint) {
        throw new Error(`Unknown mock endpoint: ${key}`);
    }

    return endpoint;
}
