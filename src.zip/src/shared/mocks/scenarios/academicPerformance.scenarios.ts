import {createScenario} from './createScenario';
import {ServerError} from "@/utils/api-models.ts";
import {Course} from "@/api/students/models.ts";


const basePerf: Course[] = [
    {
        year: 2026,
        course: 1,
        subjects: [
            {
                name: "Sara Quitzon",
                classes: [
                    {
                        date: "11.02.2026",
                        topic: "Кости черепа",
                        type: "Практика",
                        grade: {
                            type: "success",
                            message: "Отлично",
                        },
                        attendance: {
                            type: "success",
                            message: "Присутствовал",
                        },
                    },
                    {
                        date: "12.02.2026",
                        topic: "Кости черепа",
                        type: "Лекция",
                        grade: {
                            type: "error",
                            message: "Неуд",
                        },
                        attendance: {
                            type: "success",
                            message: "Присутствовал",
                        },
                    },
                ],
            },
            {
                name: "Irene Grady I",
                classes: [
                    {
                        date: "12.02.2026",
                        topic: "Кости черепа",
                        type: "Лекция",
                        grade: {
                            type: "default",
                            message: "Без оценки",
                        },
                        attendance: {
                            type: "error",
                            message: "Отсутствовал",
                        },
                    },
                ],
            },
        ],
    },
];

export const academicPerformanceScenarios = [
    createScenario<Course[]>({
        id: 'default',
        label: 'Несколько курсов',
        status: 200,
        body: basePerf,
    }),

    createScenario<Course[]>({
        id: 'empty',
        label: 'Курсов нет',
        status: 200,
        body: [],
    }),

    createScenario<ServerError>({
        id: 'unauthorized',
        label: '401',
        status: 401,
        body: {
            status: 401,
            message: 'Требуется авторизация'
        },
    }),

    createScenario<ServerError>({
        id: 'forbidden',
        label: '403',
        status: 403,
        body: {
            status: 403,
            message: 'Недостаточно прав'
        },
    }),

    createScenario<ServerError>({
        id: 'server-error',
        label: '500',
        status: 500,
        body: {
            status: 500,
            message: 'Внутренняя ошибка сервера'
        },
    }),
] as const;
