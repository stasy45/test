import {http, HttpResponse, type HttpHandler} from 'msw';

import {resolveScenarioBody} from './scenarios/createScenario';
import {mockEndpoints, type MockEndpointKey} from './scenarios/registry';

/**
 * Единственный источник истины для формы селекта сценариев.
 * Экспортируется отсюда, а не из widgets/DevModeWidget, потому что этот
 * shared-слой не должен зависеть от вышестоящего слоя (widgets).
 */
export type ScenarioSelection = Record<MockEndpointKey, string>;

/**
 * Строит массив MSW handlers, по одному на каждый зарегистрированный эндпоинт.
 * Активный сценарий для эндпоинта берётся из selection, а если для ключа
 * ничего не выбрано (например, добавили новый эндпоинт) — используется дефолт.
 */
export function buildMockHandlers(selection: ScenarioSelection): HttpHandler[] {
    return mockEndpoints.map((endpoint) => {
        const selectedId = selection[endpoint.key as MockEndpointKey] ?? endpoint.defaultScenarioId;
        const scenario =
            endpoint.scenarios.find((item) => item.id === selectedId) ??
            endpoint.scenarios.find((item) => item.id === endpoint.defaultScenarioId)!;

        return http[endpoint.method](endpoint.url, async () => {
            if (scenario.delay) {
                await new Promise((resolve) => setTimeout(resolve, scenario.delay));
            }

            return HttpResponse.json(resolveScenarioBody(scenario), {status: scenario.status});
        });
    });
}
