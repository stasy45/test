import {
    combine,
    createStore,
    sample,
    type Event,
    type Store,
} from "effector";
import {ServerError} from "@/utils/api-models.ts";




export const extractServerError = (error: unknown): ServerError => {
    const err = error as {
        response?: {
            status?: number;
            data?: {
                message?: string;
                error?: string;
                description?: string;
            };
        };
        message?: string;
    };

    return {
        message:
            err.response?.data?.message ??
            err.response?.data?.error ??
            err.message ??
            "Unexpected error",

        status: err.response?.status,
        description: err.response?.data?.description,
    };
};


type ServerErrorEffect = {
    failData: Event<unknown>;
    done: Event<unknown>;
};


export function createServerErrorStore(
    input: ServerErrorEffect | ServerErrorEffect[],
): Store<ServerError | null> {
    const effects = Array.isArray(input)
        ? input
        : [input];

    const $errors = effects.map((fx) => {
        const $error = createStore<ServerError | null>(null);

        sample({
            clock: fx.failData,
            fn: extractServerError,
            target: $error,
        });

        sample({
            clock: fx.done,
            fn: () => null,
            target: $error,
        });

        return $error;
    });

    return combine(
        $errors,
        (errors) => errors.find(Boolean) ?? null,
    );
}