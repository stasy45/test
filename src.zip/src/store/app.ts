import {createEffect, createEvent, createStore, sample} from 'effector';

import {appService} from '@/api/application/service.ts';
import type {ApplicationInfo} from '@/api/application/models.ts';
import {createServerErrorStore} from '@/shared/effector';

export const appStarted = createEvent();
export const appDataRefreshRequested = createEvent();

const getApplicationInfoFx = createEffect(appService.getApplicationInfo);

export const $serverError = createServerErrorStore(getApplicationInfoFx);
export const $appInfoLoading = getApplicationInfoFx.pending;
export const $appInfo = createStore<ApplicationInfo | null>(null).on(
    getApplicationInfoFx.doneData,
    (_, info) => info,
);

sample({
    clock: appStarted,
    target: appDataRefreshRequested,
});

sample({
    clock: appDataRefreshRequested,
    target: getApplicationInfoFx,
});

// header visibility

export const compactHeaderShown = createEvent();
export const compactHeaderHidden = createEvent();

export const $isCompactHeaderVisible = createStore(false)
    .on(compactHeaderShown, () => true)
    .on(compactHeaderHidden, () => false);