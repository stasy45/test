import {isAxiosError} from 'axios';
import {createEffect, createEvent, createStore, sample} from 'effector';

import {authService} from '@/api/auth/service';
import type {CsrfModel} from '@/api/auth/models';
import {registerHttpSecurityAdapter} from '@/api/http';
import type {CurrentUser} from '@/api/users/models.ts';
import {userService} from '@/api/users/service.ts';
import {appDataRefreshRequested} from '@/store/app';

export type AuthStatus = 'unknown' | 'authenticated' | 'unauthenticated' | 'error';

export const getCurrentUserFx = createEffect(userService.getCurrentUser);
const getCsrfFx = createEffect(authService.getCsrf);
const logoutFx = createEffect(authService.logout);

export const login = createEvent();
export const logout = createEvent();
export const retrySession = createEvent();
const sessionExpired = createEvent();

const REDIRECT_LOOP_GUARD_KEY = 'auth:keycloakRedirectAt';
const REDIRECT_LOOP_WINDOW_MS = 4000;

const startLoginFx = createEffect(() => {
    const lastAttemptAt = Number(sessionStorage.getItem(REDIRECT_LOOP_GUARD_KEY) ?? 0);
    const now = Date.now();

    if (now - lastAttemptAt < REDIRECT_LOOP_WINDOW_MS) {
        throw new Error(
            'Login redirect loop detected: /oauth2/authorization/keycloak did not leave the SPA. ' +
            'Проверьте proxy для OAuth2 endpoint.',
        );
    }

    sessionStorage.setItem(REDIRECT_LOOP_GUARD_KEY, String(now));
    authService.startLogin();
});

let cachedCsrf: CsrfModel | null = null;
let inFlightCsrfRequest: Promise<CsrfModel> | null = null;

const resolveCsrfToken = (): Promise<CsrfModel> => {
    if (cachedCsrf) return Promise.resolve(cachedCsrf);

    inFlightCsrfRequest ??= getCsrfFx()
        .then((csrf) => {
            cachedCsrf = csrf;
            return csrf;
        })
        .finally(() => {
            inFlightCsrfRequest = null;
        });

    return inFlightCsrfRequest;
};

const invalidateCsrf = () => {
    cachedCsrf = null;
    inFlightCsrfRequest = null;
};

registerHttpSecurityAdapter({
    getCsrfHeader: async () => {
        const csrf = await resolveCsrfToken();
        return {name: csrf.headerName, value: csrf.token};
    },
    invalidateCsrf,
    onUnauthorized: sessionExpired,
});

const statusFromSessionError = (error: unknown): AuthStatus =>
    isAxiosError(error) && error.response?.status === 401 ? 'unauthenticated' : 'error';

const $authStatus = createStore<AuthStatus>('unknown')
    .on(getCurrentUserFx.done, () => 'authenticated')
    .on(getCurrentUserFx.fail, (_, {error}) => statusFromSessionError(error))
    .on(sessionExpired, () => 'unauthenticated')
    .on(logout, () => 'unknown')
    .on(startLoginFx.fail, () => 'error');

const $currentUser = createStore<CurrentUser | null>(null)
    .on(getCurrentUserFx.doneData, (_, user) => user)
    .reset(logout, sessionExpired);

const $isAuthorized = $authStatus.map((status) => status === 'authenticated');
const $isLoading = getCurrentUserFx.pending;

getCurrentUserFx.done.watch(() => {
    sessionStorage.removeItem(REDIRECT_LOOP_GUARD_KEY);
});

sample({
    clock: [appDataRefreshRequested, retrySession],
    target: getCurrentUserFx,
});

sample({
    clock: login,
    source: startLoginFx.pending,
    filter: (isPending) => !isPending,
    target: startLoginFx,
});

sample({
    clock: logout,
    target: logoutFx,
});

logoutFx.done.watch(invalidateCsrf);

sample({
    clock: $authStatus,
    filter: (status): status is 'unauthenticated' => status === 'unauthenticated',
    target: login,
});

export const authModel = {
    status: $authStatus,
    isAuthorized: $isAuthorized,
    isAuthLoading: $isLoading,
    currentUser: $currentUser,
    isLoading: $isLoading,
    login,
    logout,
    retrySession,
};
