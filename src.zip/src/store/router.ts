// store/router.ts
import {createEffect, createEvent, createStore, sample} from 'effector';
import {createGate, useGate} from 'effector-react';
import {useEffect} from 'react';
import {
    useLocation,
    useNavigate,
    type Location as RRDLocation,
    type NavigateFunction,
    type NavigateOptions,
} from 'react-router-dom';

type Location = RRDLocation;

type SearchParams = Record<string, string>;

type NavigatePayload =
    | string
    | ({
    to?: string;
    searchParams?: SearchParams;
} & NavigateOptions);

const RouterGate = createGate<{ navigate: NavigateFunction }>();

const locationChanged = createEvent<Location>();
const navigateRequested = createEvent<NavigatePayload>();

const $location = createStore<Location | null>(null).on(
    locationChanged,
    (_, location) => location,
);

const $pathname = $location.map((location) => location?.pathname ?? '/');

const $navigate = createStore<NavigateFunction | null>(null).on(
    RouterGate.open,
    (_, {navigate}) => navigate,
);

const baseNavigateFx = createEffect<
    { navigate: NavigateFunction; payload: NavigatePayload },
    void
>(({navigate, payload}) => {
    if (typeof payload === 'string') {
        navigate(payload);
        return;
    }

    const {to, searchParams, ...options} = payload;

    const search = searchParams
        ? `?${new URLSearchParams(
            Object.entries(searchParams)
                .filter(([, value]) => value !== null && value !== undefined)
                .map(([key, value]) => [key, String(value)]),
        ).toString()}`
        : undefined;

    navigate(
        {
            pathname: to,
            search,
        },
        options,
    );
});

sample({
    clock: navigateRequested,
    source: $navigate,
    filter: (navigate): navigate is NavigateFunction => {
        if (!navigate) {
            console.warn(
                'Навигация запрошена, но $navigate === null. Проверьте инициализацию RouterGate.',
            );
            return false;
        }
        return true;
    },
    fn: (navigate, payload) => ({navigate, payload}),
    target: baseNavigateFx,
});

// Хелпер для парсинга searchParams из location.search
function parseSearchParams(search: string): SearchParams {
    const params = new URLSearchParams(search);
    const result: SearchParams = {};

    for (const [key, value] of params.entries()) {
        result[key] = value;
    }

    return result;
}

const $searchParams = $location.map((location) =>
    location ? parseSearchParams(location.search) : {},
);

export const router = {
    $location,
    $pathname,
    $searchParams,

    navigate: navigateRequested,

    useRouterSync() {
        const location = useLocation();
        const navigate = useNavigate();

        useGate(RouterGate, {navigate});

        useEffect(() => {
            locationChanged(location);
        }, [location]);
    },

    '@@unitShape': () => ({
        location: $location,
        pathname: $pathname,
        searchParams: $searchParams,
        navigate: navigateRequested,
    }),
};