/// <reference types="vite/client" />
/// <reference types="vite-plugin-svgr/client" />

declare module '*.svg' {
  import { FC, SVGProps, RefAttributes } from 'react';
  const ReactComponent: React.ForwardRefExoticComponent
  SVGProps<SVGSVGElement> & RefAttributes<SVGSVGElement>;
  export default ReactComponent;
}

declare module '*.png' {
  const content: string;
  export default content;
}

declare module '*.json' {
  const content: string;
  export default content;
}

declare module "*.css";

declare module '*.scss' {
  const content: Record<string, string>;
  export default content;
}

declare module '*.module.scss' {
  const classes: Record<string, string>;
  export default classes;
}