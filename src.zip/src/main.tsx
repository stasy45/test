import ReactDOM from 'react-dom/client';

import App from './App';
import {appStarted} from './store/app';
import {ensureMockWorkerReady} from '@/shared/mocks/browser';

async function bootstrap() {
    await ensureMockWorkerReady();

    appStarted();

    ReactDOM.createRoot(document.getElementById('root')!).render(<App/>);
}

bootstrap();
