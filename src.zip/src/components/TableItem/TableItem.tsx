import type {ReactNode} from "react";
import cn from 'classnames';
import {Typography} from "@/components";
import {Orientation} from "@/utils/components";

import css from "./TableItem.module.scss";

interface TableItemProps {
    label?: string;
    className?: string;
    withLabel?: boolean;
    children: ReactNode;
    orientation?: Orientation;
    bordered?: boolean;
}

export const TableItem = ({
                              label,
                              className,
                              withLabel = true,
                              children,
                              orientation = "horizontal",
                              bordered = false,
                          }: TableItemProps) => {
    return (
        <div
            className={cn(
                css.item,
                css[orientation],
                bordered && css.bordered,
                className
            )}
        >
            {withLabel && label && <Typography.p1Bold fontColor="secondary" className={css.label}>{label}</Typography.p1Bold>}

            <div className={css.value}>{children}</div>
        </div>
    );
};