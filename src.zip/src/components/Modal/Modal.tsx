import {FC, ReactNode, useEffect, useRef} from 'react';
import {motion, AnimatePresence} from 'framer-motion';
import cn from 'classnames';

import {OverlayPortal} from '@/feature-components';

import css from './Modal.module.scss';
import {Button} from "@/components";

export interface ModalProps {
    isOpen: boolean;
    onClose: () => void;
    children: ReactNode;
    className?: string;
    /** Закрытие по клику на оверлей */
    closeOnOverlayClick?: boolean;
    /** Закрытие по Escape */
    closeOnEscape?: boolean;
    /** Блокировка прокрутки body при открытом модале */
    lockBodyScroll?: boolean;
}

export const Modal: FC<ModalProps> = ({
                                          isOpen,
                                          onClose,
                                          children,
                                          className,
                                          closeOnOverlayClick = true,
                                          closeOnEscape = true,
                                          lockBodyScroll = true,
                                      }) => {
    const modalRef = useRef<HTMLDivElement>(null);

    // Блокировка скролла body
    useEffect(() => {
        if (!lockBodyScroll) return;

        if (isOpen) {
            const originalOverflow = document.body.style.overflow;
            document.body.style.overflow = 'hidden';
            return () => {
                document.body.style.overflow = originalOverflow;
            };
        }
    }, [isOpen, lockBodyScroll]);

    // Фокус внутри модального окна и обработка Escape
    useEffect(() => {
        if (!isOpen) return;

        const previousActive = document.activeElement as HTMLElement | null;
        modalRef.current?.focus();

        const handleKeyDown = (event: KeyboardEvent) => {
            if (event.key === 'Escape' && closeOnEscape) {
                onClose();
            }
        };

        document.addEventListener('keydown', handleKeyDown);
        return () => {
            document.removeEventListener('keydown', handleKeyDown);
            previousActive?.focus();
        };
    }, [isOpen, closeOnEscape, onClose]);

    const handleOverlayClick = () => {
        if (closeOnOverlayClick) {
            onClose();
        }
    };

    const handleModalClick = (event: React.MouseEvent<HTMLDivElement>) => {
        event.stopPropagation();
    };

    return (
        <OverlayPortal>
            <AnimatePresence>
                {isOpen && (
                    <motion.div
                        className={css.overlay}
                        initial={{opacity: 0}}
                        animate={{opacity: 1}}
                        exit={{opacity: 0}}
                        transition={{duration: 0.2}}
                        onClick={handleOverlayClick}
                    >
                        <motion.div
                            ref={modalRef}
                            className={cn(css.modal, className)}
                            role="dialog"
                            aria-modal="true"
                            tabIndex={-1}
                            initial={{opacity: 0, scale: 0.95, y: -20}}
                            animate={{opacity: 1, scale: 1, y: 0}}
                            exit={{opacity: 0, scale: 0.95, y: -20}}
                            transition={{duration: 0.25, ease: 'easeOut'}}
                            onClick={handleModalClick}
                        >
                            <Button
                                variant="ghost"
                                shape="square"
                                iconName="close-circle"
                                className={css.closeButton}
                                onClick={onClose}
                                aria-label="Закрыть"
                            />
                            {children}
                        </motion.div>
                    </motion.div>
                )}
            </AnimatePresence>
        </OverlayPortal>
    );
};