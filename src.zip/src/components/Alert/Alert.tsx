import {forwardRef, memo, type HTMLAttributes, type ReactNode} from 'react';
import cn from 'classnames';
import {Icon, type IconsNames, Typography, TypographyColor} from '@/components';

import css from './Alert.module.scss';


export interface AlertProps extends HTMLAttributes<HTMLDivElement> {
    variant?: TypographyColor;
    iconName?: IconsNames;
    text: ReactNode;
    description?: ReactNode;
}

export const Alert = memo(
    forwardRef<HTMLDivElement, AlertProps>((props, ref) => {
        const {
            variant = 'blue',
            iconName,
            text,
            description,
            className,
            ...restProps
        } = props;

        return (
            <div
                ref={ref}
                role="alert"
                className={cn(css.alert, css[variant], className)}
                {...restProps}
            >
                {iconName ? (
                    <Icon name={iconName} aria-hidden="true" className={css.icon}/>
                ) : null}

                <div className={css.content}>
                    <Typography.p1 fontColor={variant}>{text}</Typography.p1>
                    {description ? <Typography.p2 fontColor="secondary">{description}</Typography.p2> : null}
                </div>
            </div>
        );
    }),
);

Alert.displayName = 'Alert';