import {forwardRef, useId, type InputHTMLAttributes} from 'react';
import cn from 'classnames';
import {Icon, IconsNames} from '@/components';
import {ComponentSize, IconPosition} from '@/utils/components';

import css from './Input.module.scss';


export interface InputProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'size'> {
    variant?: 'primary';
    size?: ComponentSize;
    iconPosition?: IconPosition;
    iconName?: IconsNames;
    wrapperClassName?: string;
}


export const Input = forwardRef<HTMLInputElement, InputProps>(
    (
        {
            className,
            variant = 'primary',
            size = 'medium',
            iconPosition = 'before',
            iconName,
            disabled,
            readOnly,
            id,
            'aria-describedby': ariaDescribedBy,
            ...restProps
        },
        ref
    ) => {
        const generatedId = useId();
        const inputId = id ?? generatedId;

        const describedBy = [ariaDescribedBy].filter(Boolean).join(' ') || undefined;

        return (
            <div
                className={cn(css.input, className, css[variant], css[size], {
                    [css.input_disabled]: disabled,
                    [css.input_readOnly]: readOnly,
                })}
            >
                {iconName && iconPosition === 'before' ? <Icon name={iconName} className={css.icon}/> : null}

                <input
                    ref={ref}
                    id={inputId}
                    className={cn(css.field, className)}
                    disabled={disabled}
                    readOnly={readOnly}
                    aria-describedby={describedBy}
                    {...restProps}
                />

                {iconName && iconPosition === 'after' ? <Icon name={iconName} className={css.icon}/> : null}
            </div>
        );
    }
);


Input.displayName = 'Input';