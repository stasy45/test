import {
  createElement,
  forwardRef,
  memo,
  type ComponentPropsWithoutRef,
  type ElementType,
  type PropsWithChildren,
  type ReactElement,
  type Ref,
} from 'react';
import cn from 'classnames';

import css from './Typography.module.scss';

// ---------- Типы ----------

export type TypographyColor = 'primary' | 'secondary' | 'tertiary' | 'accent' | 'red' | 'blue' | 'yellow' | 'green';
export type TypographyAlign = 'left' | 'center' | 'right';
export type TypographyWeight = 400 | 500 | 600 | 700 | 800;

export interface TypographyOwnProps {
  align?: TypographyAlign;
  fontColor?: TypographyColor;
  fontWeight?: TypographyWeight;
}

type TypographyComponentProps<T extends ElementType> = PropsWithChildren<
  TypographyOwnProps &
  Omit<ComponentPropsWithoutRef<T>, keyof TypographyOwnProps> & {
    as?: T;
    className?: string;
  }
>;

// ---------- Фабрика ----------

function createTypography<T extends ElementType = 'div'>(
  defaultAs: T,
  defaultClassName?: string,
) {
  const Component = forwardRef<HTMLElement, TypographyComponentProps<any>>(
    function Typography(
      { children, className, as: Tag = defaultAs, align, fontColor, fontWeight, ...restProps },
      ref,
    ) {
      const classes = cn(
        defaultClassName,
        className,
        align && css[align],
        fontColor && css[`font-color-${fontColor}` as keyof typeof css],
        fontWeight && css[`weight-${fontWeight}` as keyof typeof css],
      );

      return createElement(Tag, { ref, className: classes, ...restProps }, children);
    },
  );

  Component.displayName = `Typography(${defaultAs})`;

  return memo(Component) as <T2 extends ElementType = T>(
    props: TypographyComponentProps<T2> & { ref?: Ref<HTMLElement> }
  ) => ReactElement;
}

// ---------- Варианты ----------

export const Typography = {
  h1: createTypography('h1', css.h1),
  h2: createTypography('h2', css.h2),
  h3: createTypography('h3', css.h3),
  h4: createTypography('h4', css.h4),
  h5: createTypography('h5', css.h5),
  h6: createTypography('h6', css.h6),
  p1: createTypography('p', css.p1),
  p1Bold: createTypography('p', css.p1Bold),
  p1Italic: createTypography('p', css.p1Italic),
  p2: createTypography('p', css.p2),
};
