import {forwardRef, memo, type ComponentPropsWithoutRef, type MouseEvent} from 'react';
import cn from 'classnames';
import {Icon, IconsNames} from '@/components';
import {ComponentSize} from '@/utils/components';

import css from './GradientButton.module.scss';

type GradientButtonColor = 'blue' | 'red';

type NativeButtonProps = Omit<ComponentPropsWithoutRef<'button'>, 'children'>;

export type GradientButtonProps = NativeButtonProps & {
    iconName: IconsNames;
    text: string;
    onClick?: (event: MouseEvent<HTMLButtonElement>) => void;
    color?: GradientButtonColor;
    size?: Pick<ComponentSize, 'small'>;
    isFull?: boolean;
};

export const GradientButton = memo(
    forwardRef<HTMLButtonElement, GradientButtonProps>((props, ref) => {
        const {
            color = 'blue',
            size = 'small',
            iconName,
            text,
            className,
            type = 'button',
            disabled,
            isFull = true,
            onClick,
            ...restProps
        } = props;

        const classes = cn(
            css.button,
            css[`${size}`],
            css[color],
            isFull && css.fullWidth,
            className
        );

        return (
            <button
                ref={ref}
                type={type}
                className={classes}
                disabled={disabled}
                aria-label={isFull && text}
                title={isFull && text}
                onClick={onClick}
                {...restProps}
            >
                <div className='gap-8 align-items-center'>
                    <span className={css.icon}>
                        <Icon name={iconName} aria-hidden="true"/>
                    </span>
                    {isFull && <span className={css.text}>{text}</span>}
                </div>
                {isFull && <Icon name="line-arrow-right" aria-hidden="true"/>}
            </button>
        );
    })
);

GradientButton.displayName = 'GradientButton';