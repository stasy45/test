import {memo, useCallback, type ButtonHTMLAttributes, type FC} from 'react';
import {useLocation} from 'react-router-dom';
import cn from 'classnames';

import {Icon, IconsNames} from '../Icon';

import css from './MenuButton.module.scss';
import {router} from "@/store/router.ts";

export interface MenuButtonProps
    extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, 'onClick'> {
    iconName: IconsNames;
    label: string;
    pattern?: RegExp;
    showBadge?: boolean;
    to: string;
    isExternal?: boolean;
}

export const MenuButton: FC<MenuButtonProps> = memo(
    ({
         iconName,
         label,
         pattern,
         showBadge = false,
         to,
         isExternal = false,
         className,
         ...rest
     }) => {
        const {pathname} = useLocation();
        // An external link never matches the current in-app route.
        const isSelected = !isExternal && pattern.test(pathname);

        const handleClick = useCallback(() => {
            if (isExternal) {
                // noopener prevents the new tab from getting a `window.opener`
                // reference back to this page (security + perf best practice).
                window.open(to, '_blank', 'noopener,noreferrer');
                return;
            }

            router.navigate(to);
        }, [isExternal, to]);

        return (
            <button
                type="button"
                onClick={handleClick}
                aria-current={isSelected ? 'page' : undefined}
                className={cn(
                    css.button,
                    isSelected && css.selected,
                    className,
                )}
                {...rest}
            >
        <span className={css.icon_wrapper}>
          <Icon name={iconName}/>

            {showBadge && (
                <span
                    className={css.badge}
                    aria-hidden="true"
                />
            )}
        </span>

                <span className={css.label}>
          <span className={css.label_text}>
            {label}
          </span>
        </span>
            </button>
        );
    },
);

MenuButton.displayName = 'MenuButton';