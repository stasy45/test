import {useCallback, useEffect, useId, useRef, useState} from 'react';

export interface UsePopupButtonOptions {
    /** Управляемое состояние открытия. Если передано — хук работает как controlled */
    isOpen?: boolean;
    /** Начальное состояние в неуправляемом (uncontrolled) режиме */
    defaultOpen?: boolean;
    /** Вызывается при каждой попытке сменить состояние открытия */
    onOpenChange?: (open: boolean) => void;
    closeOnOutsideClick?: boolean;
    closeOnEsc?: boolean;
}

export interface UsePopupButtonResult {
    isOpen: boolean;
    open: () => void;
    close: () => void;
    toggle: () => void;
    /** Вешается на элемент-обёртку (кнопка + попап), чтобы отслеживать клики снаружи */
    wrapperRef: React.RefObject<HTMLDivElement>;
    /** Общий id для связки кнопки (aria-controls) и попапа (id) */
    popupId: string;
}


export function usePopupButton({
                                   isOpen: controlledOpen,
                                   defaultOpen = false,
                                   onOpenChange,
                                   closeOnOutsideClick = true,
                                   closeOnEsc = true,
                               }: UsePopupButtonOptions = {}): UsePopupButtonResult {
    const [uncontrolledOpen, setUncontrolledOpen] = useState(defaultOpen);
    const isControlled = controlledOpen !== undefined;
    const isOpen = isControlled ? controlledOpen : uncontrolledOpen;

    const wrapperRef = useRef<HTMLDivElement>(null);
    const popupId = useId();

    const setOpen = useCallback(
        (next: boolean) => {
            if (!isControlled) {
                setUncontrolledOpen(next);
            }
            onOpenChange?.(next);
        },
        [isControlled, onOpenChange],
    );

    const open = useCallback(() => setOpen(true), [setOpen]);
    const close = useCallback(() => setOpen(false), [setOpen]);
    const toggle = useCallback(() => setOpen(!isOpen), [setOpen, isOpen]);

    // Закрытие по клику вне попапа/кнопки
    useEffect(() => {
        if (!isOpen || !closeOnOutsideClick) return;

        const handleOutsideClick = (event: MouseEvent) => {
            if (
                wrapperRef.current &&
                !wrapperRef.current.contains(event.target as Node)
            ) {
                close();
            }
        };

        document.addEventListener('mousedown', handleOutsideClick);
        return () => document.removeEventListener('mousedown', handleOutsideClick);
    }, [isOpen, closeOnOutsideClick, close]);

    // Закрытие по Escape
    useEffect(() => {
        if (!isOpen || !closeOnEsc) return;

        const handleKeyDown = (event: KeyboardEvent) => {
            if (event.key === 'Escape') close();
        };

        document.addEventListener('keydown', handleKeyDown);
        return () => document.removeEventListener('keydown', handleKeyDown);
    }, [isOpen, closeOnEsc, close]);

    return {isOpen, open, close, toggle, wrapperRef, popupId};
}