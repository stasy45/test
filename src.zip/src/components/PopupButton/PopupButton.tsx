import type {MouseEvent, ReactNode} from 'react';
import {forwardRef} from 'react';
import cn from 'classnames';
import {Button, type ButtonProps} from '@/components';
import {usePopupButton} from './usePopupButton';
import css from './PopupButton.module.scss';

type Placement =
    | 'top-left'
    | 'top-center'
    | 'top-right'
    | 'bottom-left'
    | 'bottom-center'
    | 'bottom-right'
    | 'left-top'
    | 'left-center'
    | 'left-bottom'
    | 'right-top'
    | 'right-center'
    | 'right-bottom';

export type PopupButtonProps = ButtonProps & {
    children: ReactNode;
    placement?: Placement;
    closeOnOutsideClick?: boolean;
    closeOnEsc?: boolean;
    /** Управляемое состояние открытия. Если передано — компонент работает как controlled */
    isOpen?: boolean;
    /** Начальное состояние в неуправляемом (uncontrolled) режиме */
    defaultOpen?: boolean;
    /** Вызывается при каждой попытке сменить состояние открытия */
    onOpenChange?: (open: boolean) => void;
    popupClassName?: string;
    wrapperClassName?: string;
};

export const PopupButton = forwardRef<HTMLButtonElement, PopupButtonProps>(
    (
        {
            children,
            placement = 'bottom-left',
            closeOnOutsideClick = true,
            closeOnEsc = true,
            isOpen: controlledOpen,
            defaultOpen = false,
            onOpenChange,
            popupClassName,
            wrapperClassName,
            onClick,
            ...buttonProps
        },
        ref,
    ) => {
        const {isOpen, toggle, wrapperRef, popupId} = usePopupButton({
            isOpen: controlledOpen,
            defaultOpen,
            onOpenChange,
            closeOnOutsideClick,
            closeOnEsc,
        });

        const handleClick = (event: MouseEvent<HTMLButtonElement>) => {
            onClick?.(event);
            toggle();
        };

        return (
            <div ref={wrapperRef} className={cn(css.wrapper, wrapperClassName)}>
                {/*
          Приведение типа нужно из-за особенности TS: Omit не сохраняет
          дискриминацию union-типа ButtonProps (ButtonWithText | ButtonIconOnly)
          при деструктуризации. Рантайм-поведение при этом корректно —
          buttonProps содержит ровно то же множество полей, что и исходный ButtonProps.
        */}
                <Button
                    {...(buttonProps as ButtonProps)}
                    ref={ref}
                    aria-haspopup="dialog"
                    aria-expanded={isOpen}
                    aria-controls={popupId}
                    onClick={handleClick}
                />

                {isOpen && (
                    <div
                        id={popupId}
                        role="dialog"
                        className={cn(css.popup, css[`popup--${placement}`], popupClassName)}
                    >
                        {children}
                    </div>
                )}
            </div>
        );
    },
);

PopupButton.displayName = 'PopupButton';