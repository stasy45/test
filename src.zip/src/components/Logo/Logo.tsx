import {FC, SVGProps} from 'react';

import LogoSmallIllustration from '@/assets/illustrations/logo-small.svg';
import LogoFullIllustration from '@/assets/illustrations/logo-full.svg';


type LogoVariant = 'full' | 'small';


interface LogoProps extends SVGProps<SVGSVGElement> {
    variant?: LogoVariant;
}


const LOGO_MAP: Record<LogoVariant, string> = {
    full: LogoFullIllustration,
    small: LogoSmallIllustration,
};

export const Logo: FC<LogoProps> = ({variant: size = 'small', ...svgProps}) => {
    const LogoIllustration = LOGO_MAP[size];

    return <LogoIllustration {...svgProps} />;
};