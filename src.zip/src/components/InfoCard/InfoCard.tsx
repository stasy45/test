import type {ReactNode} from "react";
import cn from "classnames";
import {Typography, Separator, Icon, IconsNames, GradientButton} from "@/components";
import {Orientation} from "@/utils/components";

import css from "./InfoCard.module.scss";

export interface InfoCardAction {
    iconName: IconsNames;
    label?: string;
    onClick: () => void;
}

interface InfoCardProps {
    title: string;
    className?: string;
    children: ReactNode;
    status?: ReactNode;
    iconName?: IconsNames;
    orientation?: Orientation;
    /** Если передан и orientation === "horizontal" — вместо иконки рендерятся кнопки */
    actions?: InfoCardAction[];
}

export const InfoCard = ({
                             title,
                             className,
                             children,
                             status,
                             iconName,
                             orientation = "vertical",
                             actions,
                         }: InfoCardProps) => {
    const showActions = orientation === "horizontal" && !!actions?.length;

    return (
        <div className={cn(css.card, css[orientation], className)}>
            <header className={css.header}>
                {showActions ? (
                    <div className={css.actions}>
                        {actions!.map(({iconName: actionIcon, label, onClick}, idx) => (
                            <GradientButton
                                size="small"
                                key={idx}
                                text={label}
                                color="blue"
                                isFull={false}
                                iconName={actionIcon}
                                onClick={onClick}
                                aria-label={label}
                            />
                        ))}
                    </div>
                ) : (
                    <span className={css.icon}>
                        <Icon name={iconName} aria-hidden="true"/>
                    </span>
                )}

                <Typography.h4 className="w-100" fontColor="accent">{title}</Typography.h4>

                {status && (
                    <>
                        <Separator className={css.separator} orientation="vertical" variant="accent"/>
                        <Typography.h5 className={css.status} fontColor="accent">
                            {status}
                        </Typography.h5>
                    </>
                )}
            </header>

            <div className={css.content}>{children}</div>
        </div>
    );
};