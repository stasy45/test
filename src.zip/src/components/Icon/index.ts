import { IconMap } from './mappings';

export { Icon } from './Icon';
export type IconsNames = keyof typeof IconMap;