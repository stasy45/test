import Briefcase from '@/assets/icons/briefcase.svg';
import Caduceus from '@/assets/icons/caduceus.svg';
import Document from '@/assets/icons/document.svg';
import Folder from '@/assets/icons/folder.svg';
import Notification from '@/assets/icons/notification.svg';
import Profile from '@/assets/icons/profile.svg';
import Logout from '@/assets/icons/logout.svg';
import Refresh from '@/assets/icons/refresh.svg';
import Home from '@/assets/icons/home.svg';
import SMS from '@/assets/icons/sms.svg';
import Call from '@/assets/icons/call.svg';
import LineArrowRight from '@/assets/icons/line-arrow-right.svg';
import Warning2 from '@/assets/icons/warning-2.svg';
import Book from '@/assets/icons/book.svg';
import BookLine from '@/assets/icons/book-line.svg';
import Calendar from '@/assets/icons/calendar.svg';
import CalendarLine from '@/assets/icons/calendar-line.svg';
import Education from '@/assets/icons/education.svg';
import CloseCircle from '@/assets/icons/close-circle.svg';
import TickSquare from '@/assets/icons/tick-square.svg';
import Danger from '@/assets/icons/danger.svg';
import Receipt from '@/assets/icons/receipt.svg';
import SearchNormal from '@/assets/icons/search-normal.svg';
import Printer from '@/assets/icons/printer.svg';
import Menu from '@/assets/icons/menu.svg';


export const IconMap = {
    'briefcase': Briefcase,
    'caduceus': Caduceus,
    'document': Document,
    'folder': Folder,
    'notification': Notification,
    'profile': Profile,
    'logout': Logout,
    'refresh': Refresh,
    'home': Home,
    'sms': SMS,
    'call': Call,
    'line-arrow-right': LineArrowRight,
    'warning-2': Warning2,
    'book': Book,
    'book-line': BookLine,
    'calendar': Calendar,
    'calendar-line': CalendarLine,
    'education': Education,
    'close-circle': CloseCircle,
    'tick-square': TickSquare,
    'danger': Danger,
    'receipt': Receipt,
    'search-normal': SearchNormal,
    'printer': Printer,
    'menu': Menu,
}