import { memo, type JSX } from 'react';
import { IconMap } from './mappings';



export type IconsNames = keyof typeof IconMap;


export type IconProps = {
  name: IconsNames;
  /**
   * Иконка на замену, если `name` не найден в IconMap.
   */
  fallback?: IconsNames;
} & Omit<JSX.IntrinsicElements['svg'], 'name'>;


const isKnownIcon = (value: string): value is IconsNames => value in IconMap;



export const Icon = memo((props: IconProps) => {
  const {
    name,
    fallback,
    role,
    'aria-label': ariaLabel,
    'aria-labelledby': ariaLabelledby,
    ...svgProps
  } = props;

  const resolvedName = isKnownIcon(name) ? name : fallback;

  if (!resolvedName) {
    console.error(
      `Icon: неизвестное имя иконки "${name}", fallback не задан. Проверьте IconMap или добавьте проп fallback.`
    );
    return null;
  }

  const Svg = IconMap[resolvedName];

  const isLabelled = Boolean(ariaLabel || ariaLabelledby || role);

  return (
    <Svg
      focusable={false}
      aria-hidden={isLabelled ? undefined : true}
      aria-label={ariaLabel}
      aria-labelledby={ariaLabelledby}
      {...svgProps}
    />
  );
});


Icon.displayName = 'Icon';