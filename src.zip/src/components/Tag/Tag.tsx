import cn from 'classnames';
import { Icon, IconsNames, Typography, TypographyColor } from '@/components';

import css from './Tag.module.scss';



interface TagProps {
    text: string;
    icon?: IconsNames;
    color?: TypographyColor;
    className?: string;
}

export const Tag = ({
    text,
    icon,
    color = 'secondary',
    className,
}: TagProps) => {
    return (
        <span className={cn(css.tag, css[color], className)}>
            {icon && <Icon name={icon} />}
            <Typography.p1 fontColor={color} className={css.text}>{text}</Typography.p1>
        </span>
    );
};