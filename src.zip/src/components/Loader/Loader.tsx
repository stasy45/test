import React, {FC} from 'react';
import cn from 'classnames';
import css from './Loader.module.scss';

interface LoaderProps {
    className?: string
}


export const Loader: FC<LoaderProps> = ({className}) => {

    return (
        <div className={cn(css.loader_container, className)}>
            <svg width="75" height="75" viewBox="0 0 75 75" fill="none" xmlns="http://www.w3.org/2000/svg">
                <circle cx="38" cy="38" r="31.5" stroke="var(--accent)"/>
                <circle className={css.point} cx="38" cy="38" r="6" fill="var(--accent)"/>
            </svg>
        </div>
    );
}