import {forwardRef, memo, type ReactNode} from 'react';
import {AnimatePresence, motion} from 'framer-motion';
import cn from 'classnames';

import {useDelayedTrue} from '@/hooks';
import {Loader} from './Loader';

import css from './TransitionSwitch.module.scss';


interface TransitionSwitchProps {
    isLoading: boolean;
    children: ReactNode;
    className?: string;
    /** Задержка показа лоадера (ms) — чтобы не мигать на быстрых загрузках */
    loaderDelay?: number;
    /** Размер лоадера по высоте (px) */
    loaderSize?: number;
}


export const TransitionSwitch = memo(
    forwardRef<HTMLDivElement, TransitionSwitchProps>((props, ref) => {
        const {
            isLoading,
            children,
            className,
            loaderDelay = 10,
        } = props;

        const showLoader = useDelayedTrue(isLoading, loaderDelay);

        return (
            <div
                ref={ref}
                className={css.container}
                aria-busy={isLoading || undefined}
            >
                <AnimatePresence mode="wait" initial={false}>
                    {isLoading ? (showLoader ? (
                        <motion.div
                            key="loader"
                            className={css.loader}
                            initial={{opacity: 0}}
                            animate={{opacity: 1}}
                            exit={{opacity: 0}}
                            transition={{duration: 0.25}}
                        >
                            <Loader />
                        </motion.div>
                    ) : null) : (
                        <motion.div
                            key="content"
                            className={cn(css.content, className)}
                            initial={{opacity: 0}}
                            animate={{opacity: 1}}
                            exit={{opacity: 0}}
                            transition={{duration: 0.3}}
                        >
                            {children}
                        </motion.div>
                    )}
                </AnimatePresence>
            </div>
        );
    }),
);


TransitionSwitch.displayName = 'TransitionSwitch';
