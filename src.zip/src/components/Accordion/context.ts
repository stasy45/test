import {createContext, useContext} from 'react';

export type AccordionVariant = 'lined' | 'card';

type AccordionContextValue = {
    isOpen: boolean;
    toggle: () => void;
    variant: AccordionVariant;
    headerId: string;
    contentId: string;
};

export const AccordionContext = createContext<AccordionContextValue | null>(null);

export const useAccordionContext = (): AccordionContextValue => {
    const context = useContext(AccordionContext);

    if (!context) {
        throw new Error('Accordion.Header / Accordion.Content должны быть внутри <Accordion>');
    }

    return context;
};
