import {FC, ReactNode, useCallback, useEffect, useId, useMemo, useRef, useState} from 'react';
import cn from 'classnames';
import css from './Accordion.module.scss';
import {AccordionContext, AccordionVariant, useAccordionContext} from './context';
import {IconPosition} from "@/utils/components.ts";

const ChevronIcon: FC<{ isOpen: boolean }> = ({isOpen}) => (
    <svg
        className={css.icon}
        data-open={isOpen}
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
    >
        <path
            d="M19.3896 8.41974C19.6825 8.12688 20.1572 8.12693 20.4501 8.41974C20.743 8.71264 20.743 9.1874 20.4501 9.48029L13.9306 16.0008C12.8677 17.0636 11.1321 17.0636 10.0693 16.0008L3.54975 9.48029C3.25685 9.1874 3.25685 8.71264 3.54975 8.41974C3.84264 8.12685 4.3174 8.12685 4.61029 8.41974L11.1308 14.9393C11.6079 15.4164 12.393 15.4164 12.8701 14.9393L19.3896 8.41974Z"
            fill="#2C91CF"/>
    </svg>
);


type AccordionHeaderProps = {
    children: ReactNode;
    /** С какой стороны от заголовка рисовать шеврон. По умолчанию 'end'. */
    iconPosition?: IconPosition;
};

const AccordionHeader: FC<AccordionHeaderProps> = ({children, iconPosition = 'before'}) => {
    const {isOpen, toggle, headerId, contentId} = useAccordionContext();

    return (
        <button
            type="button"
            id={headerId}
            className={css.header}
            data-open={isOpen}
            onClick={toggle}
            aria-expanded={isOpen}
            aria-controls={contentId}
        >
            {iconPosition === 'before' && <ChevronIcon isOpen={isOpen}/>}
            <span>{children}</span>
            {iconPosition === 'after' && <ChevronIcon isOpen={isOpen}/>}
        </button>
    );
};

type AccordionContentProps = {
    children: ReactNode;
};

const AccordionContent: FC<AccordionContentProps> = ({children}) => {
    const {
        isOpen,
        variant,
        toggle,
        headerId,
        contentId,
    } = useAccordionContext();

    const isLined = variant === 'lined';

    const bodyRef = useRef<HTMLDivElement>(null);
    const innerRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const body = bodyRef.current;
        const inner = innerRef.current;

        if (!body || !inner) {
            return;
        }

        const updateHeight = () => {
            body.style.height = isOpen
                ? `${inner.scrollHeight}px`
                : '0px';
        };

        updateHeight();

        const observer = new ResizeObserver(() => {
            if (isOpen) {
                body.style.height = `${inner.scrollHeight}px`;
            }
        });

        observer.observe(inner);

        return () => observer.disconnect();
    }, [isOpen]);

    return (
        <div
            ref={bodyRef}
            id={contentId}
            role="region"
            aria-labelledby={headerId}
            aria-hidden={!isOpen}
            className={css.body}
        >
            <div
                ref={innerRef}
                className={css.bodyInner}
            >
                {isLined && (
                    <button
                        type="button"
                        className={css.stripe}
                        onClick={toggle}
                        aria-expanded={isOpen}
                        aria-controls={contentId}
                        aria-label="Свернуть/развернуть"
                        tabIndex={isOpen ? 0 : -1}
                    />
                )}

                <div className={css.content}>
                    {children}
                </div>
            </div>
        </div>
    );
};

type AccordionProps = {
    variant?: AccordionVariant;
    /** Состояние по умолчанию для неконтролируемого режима. */
    defaultOpen?: boolean;
    /** Если передан — компонент становится контролируемым снаружи. */
    open?: boolean;
    onOpenChange?: (open: boolean) => void;
    children: ReactNode;
};

type AccordionComponent = FC<AccordionProps> & {
    Header: typeof AccordionHeader;
    Content: typeof AccordionContent;
};

export const Accordion: AccordionComponent = ({
                                                  variant = 'lined',
                                                  defaultOpen = false,
                                                  open: controlledOpen,
                                                  onOpenChange,
                                                  children,
                                              }) => {
    const baseId = useId();
    const [uncontrolledOpen, setUncontrolledOpen] = useState(defaultOpen);

    const isControlled = controlledOpen !== undefined;
    const isOpen = isControlled ? controlledOpen : uncontrolledOpen;

    const toggle = useCallback(() => {
        const next = !isOpen;

        if (!isControlled) {
            setUncontrolledOpen(next);
        }

        onOpenChange?.(next);
    }, [isOpen, isControlled, onOpenChange]);

    const contextValue = useMemo(
        () => ({
            isOpen,
            toggle,
            variant,
            headerId: `${baseId}-header`,
            contentId: `${baseId}-content`,
        }),
        [isOpen, toggle, variant, baseId],
    );

    return (
        <AccordionContext.Provider value={contextValue}>
            <div data-open={isOpen} className={cn(css.root, css[variant])}>
                {children}
            </div>
        </AccordionContext.Provider>
    );
};

Accordion.Header = AccordionHeader;
Accordion.Content = AccordionContent;