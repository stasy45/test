import cn from 'classnames';
import { Orientation } from '@/utils/components';

import css from './Separator.module.scss';
import { TypographyColor } from '../Typography';



interface SeparatorProps {
    orientation?: Orientation;
    variant?: TypographyColor;
    className?: string;
}

export const Separator = ({
    orientation = 'horizontal',
    variant = 'primary',
    className,
}: SeparatorProps) => {
    return (
        <div
            className={cn(css.separator, css[orientation], css[variant], className)}
            role="separator"
            aria-orientation={orientation}
        />
    );
};