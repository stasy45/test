import {useMemo, useState} from 'react';
import cn from 'classnames';
import {ComponentSize} from '@/utils/components';

import css from './Avatar.module.scss';

// Сигнатуры (magic bytes) начала base64-строки для основных форматов изображений
const BASE64_MIME_SIGNATURES: Record<string, string> = {
    '/9j/': 'image/jpeg',
    iVBORw0KGgo: 'image/png',
    R0lGODdh: 'image/gif',
    R0lGODlh: 'image/gif',
    UklGR: 'image/webp',
};

const isDataUrl = (value: string) => /^data:image\/[\w+.-]+;base64,/.test(value);
const isHttpUrl = (value: string) => /^(https?:)?\/\//.test(value) || value.startsWith('blob:');
const isLikelyBase64 = (value: string) => value.length % 4 === 0 && /^[A-Za-z0-9+/]+={0,2}$/.test(value);

const detectMimeType = (base64: string): string => {
    const signature = Object.keys(BASE64_MIME_SIGNATURES).find((sig) => base64.startsWith(sig));
    return signature ? BASE64_MIME_SIGNATURES[signature] : 'image/png';
};

/**
 * Приводит src к валидному значению для <img>: URL, готовый data-URI
 * или чистый base64 (с явным или автоопределённым MIME-типом)
 */
const resolveImageSrc = (src?: string, mimeType?: string): string | undefined => {
    if (!src) return undefined;
    if (isDataUrl(src) || isHttpUrl(src)) return src;
    if (isLikelyBase64(src)) return `data:${mimeType ?? detectMimeType(src)};base64,${src}`;
    return src;
};

interface AvatarProps {
    /** URL картинки, готовый data-URI или base64-строка без префикса */
    src?: string;
    /** MIME-тип для случая base64-строки без префикса, например 'image/png'. Если не передан, определяется автоматически по сигнатуре */
    mimeType?: string;
    initials: string;
    alt?: string;
    size?: ComponentSize;
    className?: string;
}

export const Avatar = ({
                           src,
                           mimeType,
                           initials,
                           alt = '',
                           size = 'small',
                           className,
                       }: AvatarProps) => {
    const resolvedSrc = useMemo(() => resolveImageSrc(src, mimeType), [src, mimeType]);

    const [imageError, setImageError] = useState(false);
    const [erroredSrc, setErroredSrc] = useState<string | undefined>(undefined);

    if (imageError && erroredSrc !== resolvedSrc) {
        setImageError(false);
    }

    const showImage = Boolean(resolvedSrc) && !imageError;

    return (
        <div className={cn(css.avatar, css[size], className)}>
            {showImage ? (
                <img
                    src={resolvedSrc}
                    alt={alt}
                    className={css.image}
                    onError={() => {
                        setImageError(true);
                        setErroredSrc(resolvedSrc);
                    }}
                />
            ) : (
                <span className={css.initials}>{initials}</span>
            )}
        </div>
    );
};