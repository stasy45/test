import { forwardRef, memo, type ComponentPropsWithoutRef, type MouseEvent } from 'react';
import cn from 'classnames';
import { Icon, IconsNames, Loader } from '@/components';
import { ComponentSize, IconPosition } from '@/utils/components';

import css from './Button.module.scss';



type ButtonVariant = 'primary' | 'secondary' | 'ghost';
type ButtonShape = 'rect' | 'square';


type NativeButtonProps = Omit<ComponentPropsWithoutRef<'button'>, 'children'>;


type ButtonOwnProps = {
  variant?: ButtonVariant;
  size?: ComponentSize;
  shape?: ButtonShape;
  fullWidth?: boolean;
  iconPosition?: IconPosition;
  iconName?: IconsNames;
  isLoading?: boolean;
  /** Визуально активна, но не реагирует на клики/клавиатуру (сохраняет фокусируемость) */
  readOnly?: boolean;
};


// Если текста нет (icon-only кнопка), aria-label обязателен —
// иначе у кнопки не будет доступного имени для скринридера.
type ButtonWithText = NativeButtonProps &
  ButtonOwnProps & {
    text: string | number;
  };


type ButtonIconOnly = NativeButtonProps &
  ButtonOwnProps & {
    text?: undefined;
    'aria-label'?: string;
  };


export type ButtonProps = ButtonWithText | ButtonIconOnly;


const hasVisibleText = (text: ButtonProps['text']): text is string | number =>
  text !== undefined && text !== null && text !== '';



export const Button = memo(
  forwardRef<HTMLButtonElement, ButtonProps>((props, ref) => {
    const {
      variant = 'primary',
      size = 'big',
      shape = 'rect',
      iconPosition = 'before',
      iconName,
      className,
      text,
      type = 'button',
      isLoading = false,
      disabled,
      readOnly = false,
      fullWidth = false,
      onClick,
      ...restProps
    } = props;

    const isDisabled = isLoading || disabled;

    const classes = cn(
      css.button,
      css[variant],
      css[`${size}-${shape}`],
      fullWidth && css.fullWidth,
      className
    );

    // Определяем, ЧТО рендерим. При загрузке лоадер заменяет иконку.
    const activeElement = isLoading ? (
      <Loader />
    ) : iconName ? (
      <Icon name={iconName} aria-hidden="true" />
    ) : null;

    // Определяем, КУДА рендерим.
    // Если идёт загрузка и иконки нет, форсируем позицию 'after' и гарантированно очищаем 'before'.
    const forceAfterPosition = isLoading && !iconName;

    const contentBefore = !forceAfterPosition && iconPosition === 'before' ? activeElement : null;
    const contentAfter = forceAfterPosition || iconPosition === 'after' ? activeElement : null;

    const showText = hasVisibleText(text);

    const handleClick = (event: MouseEvent<HTMLButtonElement>) => {
      // readOnly держит кнопку фокусируемой (в отличие от disabled),
      // но блокирует активацию — как с мыши, так и с клавиатуры
      // (Enter/Space нативно транслируются браузером в click).
      if (readOnly) {
        event.preventDefault();
        return;
      }
      onClick?.(event);
    };

    return (
      <button
        ref={ref}
        type={type}
        className={classes}
        disabled={isDisabled}
        aria-busy={isLoading || undefined}
        aria-disabled={readOnly || undefined}
        data-readonly={readOnly || undefined}
        onClick={handleClick}
        {...restProps}
      >
        {contentBefore}
        {showText ? <span className={css.text}>{text}</span> : null}
        {contentAfter}
      </button>
    );
  })
);


Button.displayName = 'Button';