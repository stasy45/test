import {useNavigate} from 'react-router-dom';

export function useCloseOnNavigate() {
    const navigate = useNavigate();
    return () => navigate(-1);
}