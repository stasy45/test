import {FC, ReactNode} from 'react';
import {createPortal} from 'react-dom';

type OverlayTarget = 'overlay-root' | 'body';

function getContainer(target: OverlayTarget): Element | null {
    if (target === 'body') {
        return document.body;
    }
    return document.getElementById('overlay-root') ?? document.body;
}

type OverlayPortalProps = {
    children: ReactNode;
    target?: OverlayTarget;
};

export const OverlayPortal: FC<OverlayPortalProps> = ({
                                                          children,
                                                          target = 'overlay-root',
                                                      }) => {
    const container = getContainer(target);

    // Если вдруг контейнера нет (например, на сервере), просто не рендерим
    if (!container) {
        return null;
    }

    return createPortal(children, container);
};