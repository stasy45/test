import {createContext, useContext} from 'react';

type TabsContextValue = {
    activeSlug: string;
    setActiveSlug: (slug: string) => void;
};

export const TabsContext = createContext<TabsContextValue | null>(null);

export const useTabsContext = (): TabsContextValue => {
    const context = useContext(TabsContext);

    if (!context) {
        throw new Error('Tabs.Button / Tabs.Content должны быть внутри <Tabs>');
    }

    return context;
};
