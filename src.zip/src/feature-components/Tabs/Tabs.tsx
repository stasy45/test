import {Children, FC, isValidElement, ReactElement, ReactNode, useCallback, useEffect, useMemo} from 'react';
import {useSearchParams} from 'react-router-dom';
import cn from 'classnames';
import css from './Tabs.module.scss';
import {TabsContext, useTabsContext} from './context';

type TabsButtonProps = {
    slug: string;
    label: ReactNode;
};

const TabsButton: FC<TabsButtonProps> = ({slug, label}) => {
    const {activeSlug, setActiveSlug} = useTabsContext();
    const isActive = activeSlug === slug;

    return (
        <button
            type="button"
            role="tab"
            id={`tab-${slug}`}
            aria-selected={isActive}
            aria-controls={`tabpanel-${slug}`}
            className={cn(css.tab, isActive && css.tab_active)}
            onClick={() => setActiveSlug(slug)}
        >
            {label}
        </button>
    );
};

type TabsContentProps = {
    slug: string;
    className?: string;
    children: ReactNode;
};

const TabsContent: FC<TabsContentProps> = ({slug, className, children}) => {
    const {activeSlug} = useTabsContext();

    if (activeSlug !== slug) {
        return null;
    }

    return (
        <div
            role="tabpanel"
            id={`tabpanel-${slug}`}
            aria-labelledby={`tab-${slug}`}
            className={className}
        >
            {children}
        </div>
    );
};

const isButtonElement = (child: ReactNode): child is ReactElement<TabsButtonProps> =>
    isValidElement(child) && child.type === TabsButton;

const isContentElement = (child: ReactNode): child is ReactElement<TabsContentProps> =>
    isValidElement(child) && child.type === TabsContent;

type TabsProps = {
    /** Имя search-параметра, хранящего активный таб. По умолчанию 'tab'. */
    paramName?: string;
    children: ReactNode;
};

type TabsComponent = FC<TabsProps> & {
    Button: typeof TabsButton;
    Content: typeof TabsContent;
};

export const Tabs: TabsComponent = ({paramName = 'tab', children}) => {
    const buttons = useMemo(
        () => Children.toArray(children).filter(isButtonElement),
        [children],
    );
    const contents = useMemo(
        () => Children.toArray(children).filter(isContentElement),
        [children],
    );

    const [searchParams, setSearchParams] = useSearchParams();
    const paramValue = searchParams.get(paramName);
    const defaultSlug = buttons[0]?.props.slug ?? '';
    const activeSlug = paramValue ?? defaultSlug;

    const setActiveSlug = useCallback((slug: string) => {
        setSearchParams(
            (prev) => {
                const next = new URLSearchParams(prev);
                next.set(paramName, slug);
                return next;
            },
            {replace: true},
        );
    }, [paramName, setSearchParams]);

    // Если параметра ещё нет в URL — проставляем таб по умолчанию,
    // чтобы на вкладку можно было сразу поделиться ссылкой.
    useEffect(() => {
        if (paramValue === null && defaultSlug) {
            setActiveSlug(defaultSlug);
        }
    }, [paramValue, defaultSlug, setActiveSlug]);

    const contextValue = useMemo(
        () => ({activeSlug, setActiveSlug}),
        [activeSlug, setActiveSlug],
    );

    return (
        <TabsContext.Provider value={contextValue}>
            <div className={css.tabs}>
                <div className={css.list} role="tablist">
                    {buttons}
                </div>
                {contents}
            </div>
        </TabsContext.Provider>
    );
};

Tabs.Button = TabsButton;
Tabs.Content = TabsContent;
