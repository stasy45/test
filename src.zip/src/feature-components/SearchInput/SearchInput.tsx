import {
    forwardRef,
    useEffect,
    useRef,
    useState,
    type ChangeEvent,
    type KeyboardEvent,
} from 'react';

import {Input, type InputProps} from '@/components';

const DEFAULT_SEARCH_DELAY = 3000;

export interface SearchInputProps
    extends Omit<InputProps, 'value' | 'defaultValue' | 'onChange' | 'onKeyDown'> {
    /** Значение в контролируемом режиме */
    value?: string;
    /** Начальное значение в неконтролируемом режиме */
    defaultValue?: string;
    /** Вызывается при поиске — по Enter или спустя searchDelay после последнего ввода */
    onSearch: (value: string) => void;
    /** Вызывается при каждом изменении значения инпута, без задержки (например, для синхронизации с URL) */
    onChange?: (value: string) => void;
    /** Задержка перед автоматическим поиском, мс. По умолчанию 3000 */
    searchDelay?: number;
}

export const SearchInput = forwardRef<HTMLInputElement, SearchInputProps>(
    (
        {
            value: controlledValue,
            defaultValue = '',
            onSearch,
            onChange,
            searchDelay = DEFAULT_SEARCH_DELAY,
            ...restProps
        },
        ref
    ) => {
        const isControlled = controlledValue !== undefined;
        const [internalValue, setInternalValue] = useState(defaultValue);
        const value = isControlled ? controlledValue : internalValue;

        const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

        const clearPendingSearch = () => {
            if (timeoutRef.current) {
                clearTimeout(timeoutRef.current);
                timeoutRef.current = null;
            }
        };

        // Подчищаем таймер при размонтировании, чтобы не вызвать onSearch
        // после того, как компонент уже ушёл со страницы
        useEffect(() => clearPendingSearch, []);

        const handleChange = (event: ChangeEvent<HTMLInputElement>) => {
            const newValue = event.target.value;

            if (!isControlled) {
                setInternalValue(newValue);
            }
            onChange?.(newValue);

            clearPendingSearch();
            timeoutRef.current = setTimeout(() => {
                onSearch(newValue);
            }, searchDelay);
        };

        const handleKeyDown = (event: KeyboardEvent<HTMLInputElement>) => {
            if (event.key !== 'Enter') return;

            clearPendingSearch();
            onSearch(value);
        };

        return (
            <Input
                ref={ref}
                type="text"
                value={value}
                onChange={handleChange}
                onKeyDown={handleKeyDown}
                {...restProps}
            />
        );
    }
);

SearchInput.displayName = 'SearchInput';