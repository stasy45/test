import {FC, PropsWithChildren} from 'react';
import cn from 'classnames';
import {AnimatePresence, motion} from 'framer-motion';
import {MobileMenu, OverlayPortal} from '@/feature-components';
import {useViewportInfo} from '@/hooks';
import {DEFAULT_BREAKPOINTS} from '@/utils/device-viewport';
import {useMobileMenuContext} from './context';
import css from './MobileMenu.module.scss';
import {mobileMenuUlAnimationVariants, mobileOverlayAnimationVariants} from "@/utils/animations.ts";

interface MobileMenuListProps extends PropsWithChildren {
    className?: string;
}

export const MobileMenuList: FC<MobileMenuListProps> = ({children, className}) => {
    const {isOpen, close} = useMobileMenuContext();
    const {isMobile} = useViewportInfo({mobile: DEFAULT_BREAKPOINTS.mobile});

    if (!isMobile) {
        return <nav className={className}>{children}</nav>;
    }

    return (
        <OverlayPortal target="overlay-root">
            <AnimatePresence>
                {isOpen && (
                    <motion.nav className={cn(css.mobileMenu, className)}>
                        <motion.div
                            className={css.mobileMenu__overlay}
                            variants={mobileOverlayAnimationVariants}
                            initial="initial"
                            animate="animate"
                            exit="exit"
                            onClick={close}
                            aria-hidden
                        />
                        <motion.ul
                            className={css.mobileMenu__list}
                            variants={mobileMenuUlAnimationVariants}
                            initial="initial"
                            animate="animate"
                            exit="exit"
                            role="menu"
                        >
                            {children}
                            <MobileMenu.Button className={css.mobileMenu__button}/>
                        </motion.ul>
                    </motion.nav>
                )}
            </AnimatePresence>
        </OverlayPortal>
    );
};