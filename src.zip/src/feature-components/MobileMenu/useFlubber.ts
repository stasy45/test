import {interpolate} from 'flubber';
import {MotionValue, useTransform} from 'framer-motion';
import {getIndex} from "@/utils/helpers.ts";


export function useFlubber(progress: MotionValue<number>, paths: string[]) {
    return useTransform(progress, paths.map(getIndex), paths, {
        mixer: (a, b) => interpolate(a, b, {maxSegmentLength: 1}),
    });
}