import {FC, PropsWithChildren, useCallback, useEffect, useMemo, useState} from 'react';
import {useLocation} from 'react-router-dom';
import {useViewportInfo} from '@/hooks';
import {DEFAULT_BREAKPOINTS} from '@/utils/device-viewport';
import {MobileMenuContext} from './context';
import {MobileMenuList} from './MobileMenuList';
import {MobileMenuButton} from './MobileMenuButton';

interface MobileMenuComponent extends FC<PropsWithChildren> {
    List: typeof MobileMenuList;
    Button: typeof MobileMenuButton;
}

export const MobileMenu: MobileMenuComponent = ({children}) => {
    const {isMobile} = useViewportInfo({mobile: DEFAULT_BREAKPOINTS.mobile});
    const {pathname} = useLocation();
    const [isOpen, setIsOpen] = useState(false);

    const toggle = useCallback(() => setIsOpen(prev => !prev), []);
    const close = useCallback(() => setIsOpen(false), []);

    const resetKey = `${isMobile}:${pathname}`;
    const [prevResetKey, setPrevResetKey] = useState(resetKey);
    if (resetKey !== prevResetKey) {
        setPrevResetKey(resetKey);
        if (isOpen) setIsOpen(false);
    }

    useEffect(() => {
        if (!isMobile) return;
        document.body.style.overflow = isOpen ? 'hidden' : '';
        return () => {
            document.body.style.overflow = '';
        };
    }, [isMobile, isOpen]);

    const value = useMemo(
        () => ({isOpen, toggle, close}),
        [isOpen, toggle, close]
    );

    return (
        <MobileMenuContext.Provider value={value}>
            {children}
        </MobileMenuContext.Provider>
    );
};

MobileMenu.List = MobileMenuList;
MobileMenu.Button = MobileMenuButton;