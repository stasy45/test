import {createContext, useContext} from 'react';

interface MobileMenuContextValue {
    isOpen: boolean;
    toggle: () => void;
    close: () => void;
}

export const MobileMenuContext = createContext<MobileMenuContextValue | null>(null);

export function useMobileMenuContext() {
    const ctx = useContext(MobileMenuContext);
    if (!ctx) {
        throw new Error('MobileMenu.* must be used within <MobileMenu>');
    }
    return ctx;
}