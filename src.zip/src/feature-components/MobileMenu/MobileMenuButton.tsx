import {FC} from 'react';
import {Button} from '@/components';
import {useViewportInfo} from '@/hooks';
import {DEFAULT_BREAKPOINTS} from '@/utils/device-viewport';
import {useMobileMenuContext} from './context';

interface MobileMenuButtonProps {
    className?: string;
}

export const MobileMenuButton: FC<MobileMenuButtonProps> = ({className}) => {
    const {isOpen, toggle} = useMobileMenuContext();
    const {isMobile} = useViewportInfo({mobile: DEFAULT_BREAKPOINTS.mobile});

    if (!isMobile) return null;

    return (
        <Button
            className={className}
            variant="ghost"
            shape="square"
            iconName={isOpen ? 'close-circle' : 'menu'}
            aria-label={isOpen ? 'Закрыть меню' : 'Открыть меню'}
            aria-expanded={isOpen}
            onClick={toggle}
        />
    );
};