import {RouteObject, useRoutes} from 'react-router-dom';
import {FC} from 'react';
import {router} from '@/store/router';


import {IFrameWidget, StateWidget} from '@/widgets';
import {MainLayout} from '@/layouts/MainLayout';

import {StartedRedirect} from "@/views/StartedRedirect.tsx";
import StudentView from "@/views/StudentView";

const routes: RouteObject[] = [
    {
        path: '/',
        children: [
            {
                element: <MainLayout/>,
                children: [
                    {
                        index: true,
                        element: <StartedRedirect/>,
                    },
                    {
                        path: 'student-profile',
                        element: <StudentView/>,
                    },
                    {
                        path: 'news',
                        element: <IFrameWidget page="news" title="Новости"/>,
                    },
                    {
                        path: 'vacancy',
                        element: <StateWidget
                            code="develop"
                            variant="transparent"
                            title="Ведутся работы"
                            description="Страница в процессе разработки"
                            button={{
                                variant: 'ghost',
                                text: 'На главную',
                                icon: 'home',
                                onClick: () => router.navigate({to: '/', replace: true}),
                            }}
                        />,
                    },
                    {
                        path: 'aorta',
                        element: <IFrameWidget page="aorta" title="Аорта"/>,
                    },
                    {
                        path: 'documents',
                        element: <IFrameWidget page="documents" title="Мои документы"/>,
                    },
                    {
                        path: 'inbox',
                        element: <IFrameWidget page="inbox" title="Входящие"/>,
                    },
                    {
                        path: 'passport',
                        element: <IFrameWidget page="passport" title="Актуализация паспорта"/>,
                    },
                    {
                        path: 'test',
                        element: <StateWidget
                            code="develop"
                            variant="transparent"
                            title="Ведутся работы"
                            description="Страница в процессе разработки"
                            button={{
                                variant: 'ghost',
                                text: 'На главную',
                                icon: 'home',
                                onClick: () => router.navigate({to: '/', replace: true}),
                            }}
                        />,
                    },
                ],
            },
        ],
    },
    {
        path: 'access-denied',
        element: (
            <StateWidget
                code={403}
                title="Недостаточно прав для просмотра"
                button={{
                    variant: 'ghost',
                    text: 'На главную',
                    icon: 'home',
                    onClick: () => router.navigate({to: '/', replace: true}),
                }}
            />
        ),
    },
    {
        path: '*',
        element: (
            <StateWidget
                code={404}
                title="Страница не найдена"
                button={{
                    variant: 'ghost',
                    text: 'На главную',
                    icon: 'home',
                    onClick: () => router.navigate({to: '/', replace: true}),
                }}
            />
        ),
    },
];

const RouterSync: FC = () => {
    router.useRouterSync();
    return null;
};

export const AppRoutes: FC = () => {
    return (
        <>
            <RouterSync/>
            {useRoutes(routes)}
        </>
    );
};