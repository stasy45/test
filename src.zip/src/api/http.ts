import axios, {type InternalAxiosRequestConfig} from 'axios';


export const http = axios.create({
    baseURL: '/api',
    withCredentials: true,
    headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json; charset=utf-8',
    },
    paramsSerializer: (params) => {
        const searchParams = new URLSearchParams();

        for (const [key, value] of Object.entries(params)) {
            if (value !== undefined && value !== null && value !== '') {
                searchParams.append(key, String(value));
            }
        }

        return searchParams.toString();
    },
});


export interface HttpSecurityAdapter {
    /** Получить заголовок, который нужно добавить к небезопасным (изменяющим состояние) запросам */
    getCsrfHeader: () => Promise<{ name: string; value: string }>;
    /** Удалить сохранённые учётные данные, например после того, как сервер отклонил их */
    invalidateCsrf: () => void;
    /** Вызывается всякий раз, когда сервер сообщает, что сессия больше недействительна */
    onUnauthorized: () => void;
}

let securityAdapter: HttpSecurityAdapter | null = null;

export const registerHttpSecurityAdapter = (adapter: HttpSecurityAdapter) => {
    securityAdapter = adapter;
};

declare module 'axios' {
    export interface AxiosRequestConfig {
        skipUnauthorizedHandling?: boolean;
    }
}

type RetriableRequestConfig = InternalAxiosRequestConfig & {
    __csrfRetried?: boolean;
};

const SAFE_METHODS = new Set(['GET', 'HEAD', 'OPTIONS', 'TRACE']);

const isUnsafeMethod = (method?: string) =>
    !SAFE_METHODS.has((method ?? 'GET').toUpperCase());

http.interceptors.request.use(async (config) => {
    if (!securityAdapter || !isUnsafeMethod(config.method)) {
        return config;
    }

    const {name, value} = await securityAdapter.getCsrfHeader();
    config.headers.set(name, value);

    return config;
});

http.interceptors.response.use(
    (response) => response,
    async (error) => {
        const status = error?.response?.status;
        const config = error?.config as RetriableRequestConfig | undefined;

        if (status === 401) {
            securityAdapter?.invalidateCsrf();

            if (!config?.skipUnauthorizedHandling) {
                securityAdapter?.onUnauthorized();
            }
        }

        // Повторить небезопасный запрос один раз после обновления CSRF-токена
        if (
            status === 403 &&
            config &&
            isUnsafeMethod(config.method) &&
            !config.__csrfRetried
        ) {
            config.__csrfRetried = true;
            securityAdapter?.invalidateCsrf();
            return http.request(config);
        }

        return Promise.reject(error);
    },
);