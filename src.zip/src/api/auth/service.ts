import {http} from '@/api/http';
import type {CsrfModel, LogoutModel} from './models';


const bffBaseUrl = (import.meta.env.VITE_BFF_BASE_URL ?? '').replace(/\/$/, '');
const bffUrl = (path: string) => `${bffBaseUrl}${path}`;

const urlFactory = {
    getCsrf: '/csrf',
    postLogout: '/logout',
    startLogin: bffUrl('/oauth2/authorization/keycloak'),
};

export const authService = {
    getCsrf: async (): Promise<CsrfModel> => {
        const response = await http.get<CsrfModel>(urlFactory.getCsrf);
        return response.data;
    },

    startLogin: (): void => {
        window.location.replace(urlFactory.startLogin);
    },

    logout: async (): Promise<void> => {
        const response = await http.post<LogoutModel>(urlFactory.postLogout);
        window.location.assign(response.data.logoutUrl);
    },
};