export interface CsrfModel {
    headerName: string;
    parameterName: string;
    token: string;
}

export interface LogoutModel {
    logoutUrl: string;
}
