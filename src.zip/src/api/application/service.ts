import {http} from '@/api/http';
import type {ApplicationInfo} from './models';

const prefix = '/application';

const urlFactory = {
    getApplicationInfo: `${prefix}`,
};

export const appService = {
    getApplicationInfo: async (): Promise<ApplicationInfo> => {
        const response = await http.get<ApplicationInfo>(urlFactory.getApplicationInfo);
        return response.data;
    },
};