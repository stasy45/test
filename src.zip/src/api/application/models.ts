export interface ApplicationInfo {
    income: boolean;
    isPassportActual: boolean;
}