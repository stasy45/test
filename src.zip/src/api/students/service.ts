import {http} from '@/api/http';
import type {Course, Payment, ProfileInfo, Session} from './models';


const prefix = '/students';

const urlFactory = {
    getStudentProfile: `${prefix}/profile/me`,
    getAcademicPerformance: `${prefix}/academic-performance`,
    getSession: `${prefix}/session-result`,
    getPaymentSteps: `${prefix}/payments`,
};

export const studentsService = {
    getStudentProfile: async (): Promise<ProfileInfo> => {
        const response = await http.get<ProfileInfo>(urlFactory.getStudentProfile);
        return response.data;
    },
    getAcademicPerformance: async (studentId: string): Promise<Course[]> => {
        const response = await http.get<Course[]>(urlFactory.getAcademicPerformance, {
            params: {
                studentId
            }
        });
        return response.data;
    },
    getSession: async (studentId: string): Promise<Session[]> => {
        const response = await http.get<Session[]>(urlFactory.getSession, {
            params: {
                studentId
            }
        });
        return response.data;
    },
    getPaymentSteps: async ({studentId}): Promise<Payment> => {
        const response = await http.get<Payment>(urlFactory.getPaymentSteps, {
            params: {
                studentId
            }
        });
        return response.data;
    },
};