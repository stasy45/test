import {SystemStatus} from "@/utils/api-models.ts";


export interface ProfileInfo {
    birthday: string;
    email?: string;
    phone?: string;
    additionalStatuses?: string[];
    residence?: Residence;
    passport: Passport;
    bypass?: Bypass;
    education: Education[];
}

interface Residence {
    contract: string;
    settlementDate: string;
    ejectmentDate?: string;
}

interface Passport {
    number: string;
    serialNumber: string;
    issued: string;
    issuedDate: string;
}

interface Bypass {
    year: number;
    points: BypassPoint[];
}

interface BypassPoint {
    status: Pick<SystemStatus, 'type'>;
    name: string;
    description?: string;
}

interface Education {
    studentId: string;
    name: string;
    studentCategory: string;
    direction: string;
    group: string;
    course: number;
    financial: string;
    organization?: string;
    scholarship?: Scholarship;
    averageScore: number;
    absences: number;
    averageSessionScore: number;
}

interface Scholarship {
    type: string;
    amount: number;
}

// ======

export interface Course {
    year: number;
    course: number;
    subjects: Subject[];
}

interface Subject {
    name: string;
    classes: Class[];
}

interface Class {
    date: string;
    topic: string;
    type: string;
    grade: SystemStatus;
    attendance: SystemStatus;
}

// ======

export type Session = {
    year: number;
    course: number;
    semester: Semester[];
};

type Semester = {
    count: number;
    subjects: SessionSubject[];
};

type SessionSubject = {
    date: string;
    name: string;
    type: string;
    grade: SystemStatus;
};

// ======

export interface Payment {
    contract: string;
    steps: PaymentStep[];
}

interface PaymentStep {
    checkURL?: string;
    semester: number;
    course: number;
    dueDate: string;
    amount: number;
}