import {http} from '@/api/http';
import type {CurrentUser} from './models';


const prefix = '/users';

const urlFactory = {
    getCurrentUser: `${prefix}/me`,
};

export const userService = {
    getCurrentUser: async (): Promise<CurrentUser> => {
        const response = await http.get<CurrentUser>(urlFactory.getCurrentUser, {
            skipUnauthorizedHandling: true,
        });
        return response.data;
    },
};