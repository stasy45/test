export type UserPermission =
    | 'ACCESS_STUDENT_PROFILE'
    | 'VIEW_ALL_STUDENTS'
    | 'VIEW_DIVISION_STUDENTS'
    | 'MANAGE_PRACTICES'
    | 'MANAGE_VACANCIES'
    | 'MANAGE_BYPASS_LIST'
    | 'ADMINISTER_BYPASS_LIST'
    | 'SEND_MAX_ALL'
    | 'SEND_MAX_DIVISION';

export interface CurrentUser {
    subject: string;
    fio: string;
    initials: string;
    /** Base64-encoded PNG. */
    photo?: string;
    snils: string;
    permissions: UserPermission[];
}