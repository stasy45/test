import {StudentView} from './StudentView';
import {withAccess} from "@/shared/auth/AccessGuard.tsx";

export default withAccess(StudentView, ['ACCESS_STUDENT_PROFILE']);