import {createEffect, createStore, sample} from 'effector';
import {createGate} from 'effector-react';

import {createServerErrorStore} from '@/shared/effector';
import {appDataRefreshRequested} from '@/store/app';
import {studentsService} from "@/api/students/service.ts";
import {ProfileInfo} from "@/api/students/models.ts";


export const UserViewGate = createGate();

const getProfileInfoFx = createEffect(studentsService.getStudentProfile);

export const $serverError = createServerErrorStore(getProfileInfoFx);
export const $profileInfoLoading = getProfileInfoFx.pending;
export const $profileInfo = createStore<ProfileInfo | null>(null).on(
    getProfileInfoFx.doneData,
    (_, profile) => profile,
);

sample({
    clock: UserViewGate.open,
    target: getProfileInfoFx,
});

sample({
    clock: appDataRefreshRequested,
    source: {gate: UserViewGate.status},
    filter: ({gate}) => gate,
    target: getProfileInfoFx,
});
