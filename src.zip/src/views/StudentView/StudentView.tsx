import cn from 'classnames';
import {useGate, useUnit} from 'effector-react';
import {
    Accordion,
    Alert,
    Avatar,
    Button,
    GradientButton,
    InfoCard,
    InfoCardAction,
    Separator,
    TableItem,
    Tag,
    TransitionSwitch,
    Typography,
} from '@/components';
import {$appInfo} from '@/store/app';
import {authModel} from '@/store/auth';
import {StateWidget, useRegisterDevPage} from '@/widgets';

import {$profileInfo, $profileInfoLoading, $serverError, UserViewGate} from './model.ts';
import css from './StudentView.module.scss';
import {router} from "@/store/router.ts";
import {ICON_BY_STATUS, TYPOGRAPHY_COLOR_BY_STATUS} from "@/utils/maps.ts";
import {useMemo, useRef} from "react";
import {useCompactHeaderObserver} from "@/layouts/MainLayout/useCompactHeaderObserver.ts";
import {ProfileInfo} from "@/api/students/models.ts";
import {copyToClipboard} from "@/utils/functions.ts";
import {DEFAULT_BREAKPOINTS} from "@/utils/device-viewport.ts";
import {useViewportInfo} from "@/hooks";


type Education = ProfileInfo['education'][number];

const ProfileHeader = ({profile}: { profile: ProfileInfo }) => {
    const currentUser = useUnit(authModel.currentUser);
    const appInfo = useUnit($appInfo);
    const hasContactInfo = Boolean(profile.email || profile.phone || profile.additionalStatuses);

    const {isMobile} = useViewportInfo({mobile: DEFAULT_BREAKPOINTS.mobile});
    const sentinelRef = useRef<HTMLDivElement>(null);
    useCompactHeaderObserver(sentinelRef, !isMobile);

    return (
        <div className="gap-12">
            {
                !isMobile &&
                <div className={cn(css.card, css.fixed_width, ' flex-col align-items-center')}>
                    <Avatar size="big" src={currentUser?.photo} initials={currentUser?.initials}/>
                    <Typography.h4 align="center">{currentUser?.fio ?? '—'}</Typography.h4>
                    <Typography.h4 align="center" fontColor="secondary">
                        {profile.birthday}
                    </Typography.h4>
                </div>
            }

            <div className={css.profileHeader}>
                {appInfo && !appInfo.isPassportActual && (
                    <GradientButton
                        size="small"
                        color="red"
                        iconName="warning-2"
                        text="Актуализируйте данные паспорта"
                        onClick={() => router.navigate({to: '/passport'})}
                    />
                )}

                <div className={cn(css.profileHeader, !isMobile && 'flex-row')}>
                    {hasContactInfo &&
                    !isMobile ? (
                        <div className={cn(css.card, 'gap-12 w-30')}>
                            {profile.email && (
                                <div className="flex-col gap-4">
                                    <Typography.h5 fontColor="secondary">Почта</Typography.h5>
                                    <Button
                                        fullWidth
                                        size="medium"
                                        variant="ghost"
                                        text={profile.email}
                                        iconName="sms"
                                        onClick={() => copyToClipboard(profile.email)}
                                    />
                                </div>
                            )}

                            {profile.email && profile.phone && <Separator variant="tertiary"/>}

                            {profile.phone && (
                                <div className="flex-col gap-4">
                                    <Typography.h5 fontColor="secondary">Телефон</Typography.h5>
                                    <Button
                                        fullWidth
                                        size="medium"
                                        variant="ghost"
                                        text={profile.phone}
                                        iconName="call"
                                        onClick={() => copyToClipboard(profile.phone)}
                                    />
                                </div>
                            )}

                            {profile.additionalStatuses && (
                                <>
                                    <Separator variant="tertiary"/>
                                    <div className="gap-8 flex-wrap">
                                        {
                                            profile.additionalStatuses.map((item, idx) => (
                                                <Tag key={idx} text={item}/>
                                            ))
                                        }
                                    </div>
                                </>
                            )}
                        </div>
                    ) : (
                        <Accordion variant="card">
                            <Accordion.Header>
                                <Typography.h5 fontColor="secondary">
                                    Контакты
                                </Typography.h5>
                            </Accordion.Header>

                            <Accordion.Content>
                                {profile.email && (
                                    <Button
                                        fullWidth
                                        size="medium"
                                        variant="ghost"
                                        text={profile.email}
                                        iconName="sms"
                                        onClick={() => copyToClipboard(profile.email)}
                                    />)}

                                {profile.email && (
                                    <Button
                                        fullWidth
                                        size="medium"
                                        variant="ghost"
                                        text={profile.phone}
                                        iconName="call"
                                        onClick={() => copyToClipboard(profile.phone)}
                                    />)}
                            </Accordion.Content>
                        </Accordion>
                    )}

                    <div className={cn(css.card, !isMobile && 'w-70')}>
                        <Typography.h4>Паспортные данные</Typography.h4>
                        <TableItem bordered label="Серия, номер">
                            {profile.passport.serialNumber}
                        </TableItem>
                        <TableItem bordered label="Выдан">
                            {profile.passport.issued}
                        </TableItem>
                        <TableItem label="Дата выдачи">
                            {profile.passport.issuedDate}
                        </TableItem>
                    </div>
                </div>
                <div ref={sentinelRef}/>
            </div>
        </div>
    );
};


const EducationCard = ({education}: { education: Education }) => {
    const actions: InfoCardAction[] = useMemo(
        () => [
            {
                iconName: "book",
                label: "Текущая успеваемость",
                onClick: () => router.navigate({
                    searchParams: {
                        panel: 'academic',
                        tab: 'academic-performance',
                        studentId: education.studentId,
                        group: education.group,
                    },
                }),
            },
            {
                iconName: "calendar",
                label: "Расписание",
                onClick: () => router.navigate({
                    searchParams: {
                        panel: 'schedule',
                        studentId: education.studentId,
                        group: education.group,
                    },
                }),
            },
        ],
        [education.studentId, education.group]
    );

    const {isMobile} = useViewportInfo({mobile: DEFAULT_BREAKPOINTS.mobile});

    return (
        <InfoCard
            iconName="education"
            orientation="horizontal"
            status={education.studentCategory}
            title={education.name}
            actions={actions}
        >
            <div className="d-flex">
                <TableItem orientation="vertical" bordered label="Направление">
                    {education.direction}
                </TableItem>
                <TableItem className="w-50" orientation="vertical" bordered label="Группа">
                    {education.group}
                </TableItem>
                <TableItem className="w-50" orientation="vertical" bordered label="Курс">
                    {education.course}
                </TableItem>
            </div>

            <div className="d-flex">
                <TableItem className="w-100" orientation="vertical" bordered label="Финансирование">
                    {education.financial}
                </TableItem>
                {education.financial === 'Целевое' && education.organization && (
                    <TableItem className="w-90" orientation="vertical" bordered label="Организация">
                        {education.organization}
                    </TableItem>
                )}
                {education.financial !== 'Бюджет' && (
                    <TableItem className={!isMobile ? "w-5" : "w-10"} orientation="vertical" bordered>
                        <Button
                            size="big"
                            variant="ghost"
                            shape="square"
                            iconName="receipt"
                            onClick={() =>
                                router.navigate({
                                    searchParams: {
                                        panel: 'payments',
                                        studentId: String(education.studentId),
                                    },
                                })
                            }
                        />
                    </TableItem>
                )}
            </div>

            {education.scholarship && (
                <div className="d-flex">
                    <TableItem orientation="vertical" bordered label="Стипендия">
                        {education.scholarship.type}
                    </TableItem>
                    <TableItem orientation="vertical" bordered label="Общая сумма">
                        {education.scholarship.amount}
                    </TableItem>
                </div>
            )}

            <div className="gap-8 flex-wrap">
                <Button
                    variant="secondary"
                    size="small"
                    text={`Ср. балл: ${education.averageScore}`}
                    onClick={() => router.navigate({
                        searchParams: {
                            panel: 'academic',
                            tab: 'academic-performance',
                            studentId: String(education.studentId),
                            group: education.group,
                        },
                    })}
                />
                <Button
                    variant="secondary"
                    size="small"
                    text={`Пропуски: ${education.absences}`}
                    onClick={() => router.navigate({
                        searchParams: {
                            panel: 'academic',
                            tab: 'academic-performance',
                            studentId: String(education.studentId),
                            group: education.group,
                        },
                    })}
                />
                <Button
                    variant="secondary"
                    size="small"
                    text={`Ср. балл за сессию: ${education.averageSessionScore}`}
                    onClick={() => router.navigate({
                        searchParams: {
                            panel: 'academic',
                            tab: 'session',
                            studentId: String(education.studentId),
                            group: education.group,
                        },
                    })}
                />
            </div>
        </InfoCard>
    );
}

const ProfileContent = ({profile}: { profile: ProfileInfo }) => {
    const hasAdditionalInfo = Boolean(profile.bypass);

    return (
        <>
            <ProfileHeader profile={profile}/>

            <div className="flex-col gap-16">
                <Typography.h6 fontColor="secondary">Общая информация</Typography.h6>

                <div className="gap-16">
                    {profile.residence && (
                        <InfoCard className="w-100" title="Проживание">
                            <TableItem bordered label="Номер договора">
                                {profile.residence.contract}
                            </TableItem>
                            <TableItem bordered={Boolean(profile.residence?.ejectmentDate)} label="Дата заселения">
                                {profile.residence.settlementDate}
                            </TableItem>
                            {
                                profile.residence?.ejectmentDate &&
                                <TableItem label="Дата выселения">
                                    {profile.residence.ejectmentDate}
                                </TableItem>
                            }
                        </InfoCard>
                    )}
                </div>

                <div className="flex-col gap-16">
                    <Typography.h6 fontColor="secondary">Данные обучения</Typography.h6>

                    {profile.education.length > 0 ? (
                        profile.education.map((education) => (
                            <EducationCard
                                key={`${education.name}-${education.group}-${education.course}`}
                                education={education}
                            />
                        ))
                    ) : (
                        <Typography.h6 fontColor="secondary">
                            Данные об обучении отсутствуют
                        </Typography.h6>
                    )}
                </div>

                {hasAdditionalInfo && (
                    <div className="flex-col gap-16">
                        <Typography.h6 fontColor="secondary">Дополнительно</Typography.h6>

                        <div className="gap-16">
                            {profile.bypass && (
                                <InfoCard
                                    className="w-100"
                                    status={profile.bypass.year}
                                    title="Обходной лист"
                                >
                                    {profile.bypass.points.map((point, index) => (
                                        <Alert
                                            key={`${point.name}-${point.description ?? index}`}
                                            variant={TYPOGRAPHY_COLOR_BY_STATUS[point.status.type]}
                                            iconName={ICON_BY_STATUS[point.status.type]}
                                            text={point.name}
                                            description={point.description}
                                        />
                                    ))}
                                </InfoCard>
                            )}
                        </div>
                    </div>
                )}
            </div>
        </>
    )
        ;
};

export const StudentView = () => {
    useRegisterDevPage('profile');
    useGate(UserViewGate);

    const [profile, isLoading] = useUnit([$profileInfo, $profileInfoLoading]);
    const serverError = useUnit($serverError)

    return (
        <TransitionSwitch className="flex-col gap-28" isLoading={isLoading}>
            {!serverError && profile ? (
                <ProfileContent profile={profile}/>
            ) : (
                <StateWidget
                    code={serverError?.status}
                    title={serverError?.message}
                    description={serverError?.description}
                    button={serverError?.status === 403 && {
                        variant: 'ghost',
                        text: 'На главную',
                        icon: 'home',
                        onClick: () => router.navigate({to: '/', replace: true}),
                    }}
                />
            )}
        </TransitionSwitch>
    );
};
