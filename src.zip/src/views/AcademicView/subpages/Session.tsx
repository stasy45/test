import {FC} from "react";
import {useUnit} from "effector-react";

import {Accordion, Separator, TableItem, Tag, Typography} from "@/components";
import {StateWidget} from "@/widgets";
import {TYPOGRAPHY_COLOR_BY_STATUS} from "@/utils/maps.ts";

import {
    $filteredSession,
    $serverErrorSession,
    $session, $sessionSearchQuery, sessionSearchQueryChanged,
} from "../model.ts";
import {SearchInput} from "@/feature-components";
import {Session} from "@/api/students/models.ts";
import {router} from "@/store/router.ts";
import {useViewportInfo} from "@/hooks";
import {DEFAULT_BREAKPOINTS} from "@/utils/device-viewport.ts";


type Semester = Session["semester"][number];


type SemesterContentProps = {
    semester: Semester;
};


const SemesterContent: FC<SemesterContentProps> = ({semester}) => {
    const {subjects} = semester;

    const {isMobile} = useViewportInfo({mobile: DEFAULT_BREAKPOINTS.mobile});

    return (
        <Accordion>
            <Accordion.Header>
                <Typography.h5>
                    {semester.count} семестр
                </Typography.h5>
            </Accordion.Header>

            <Accordion.Content>
                {!subjects.length ? (
                    <StateWidget
                        variant="transparent"
                        code="empty"
                        title="Ничего не найдено"
                        description="Кажется здесь ничего нет"
                    />
                ) : (
                    subjects.map((subject, index) => {
                        const isLast = index === subjects.length - 1;

                        return (
                            <div key={index} className={isMobile ? "flex-col" : "flex-row"}>
                                <TableItem
                                    orientation="vertical"
                                    bordered={!isMobile ? !isLast : true}
                                    withLabel={!isMobile ? index === 0 : true}
                                    label="Дата"
                                >
                                    {subject.date}
                                </TableItem>

                                <TableItem
                                    orientation="vertical"
                                    bordered={!isMobile ? !isLast : true}
                                    withLabel={!isMobile ? index === 0 : true}
                                    label="Дисциплина"
                                >
                                    {subject.name}
                                </TableItem>

                                <TableItem
                                    orientation="vertical"
                                    bordered={!isMobile ? !isLast : true}
                                    withLabel={!isMobile ? index === 0 : true}
                                    label="Форма контроля"
                                >
                                    <Tag text={subject.type}/>
                                </TableItem>

                                <TableItem
                                    orientation="vertical"
                                    bordered={!isLast}
                                    withLabel={!isMobile ? index === 0 : true}
                                    label="Оценка"
                                >
                                    <Tag
                                        color={
                                            TYPOGRAPHY_COLOR_BY_STATUS[
                                                subject.grade.type
                                                ]
                                        }
                                        text={subject.grade.message}
                                    />
                                </TableItem>

                                {isMobile && !isLast && (
                                    <Separator/>
                                )}
                            </div>
                        );
                    })
                )}
            </Accordion.Content>
        </Accordion>
    );
};


const CourseContent: FC<{
    course: Session;
}> = ({course}) => {
    return (
        <Accordion>
            <Accordion.Header>
                <Typography.h4>
                    {course.year} / {course.course} курс
                </Typography.h4>
            </Accordion.Header>

            <Accordion.Content>
                {course.semester.map((semester, index) => (
                    <SemesterContent
                        key={`${course.year}-${course.course}-${index}`}
                        semester={semester}
                    />
                ))}
            </Accordion.Content>
        </Accordion>
    );
};


export const SessionPage = () => {
    const [session, filteredSession, sessionSearchQuery, serverError] = useUnit([
        $session,
        $filteredSession,
        $sessionSearchQuery,
        $serverErrorSession,
    ]);

    const handleSearch = useUnit(sessionSearchQueryChanged);

    if (serverError) {
        return (
            <StateWidget
                code={serverError?.status}
                title={serverError?.message}
                description={serverError?.description}
                button={serverError?.status === 403 && {
                    variant: 'ghost',
                    text: 'На главную',
                    icon: 'home',
                    onClick: () => router.navigate({to: '/', replace: true}),
                }}
            />
        );
    }

    if (!session || !session.length) {
        return (
            <StateWidget
                variant="transparent"
                code="empty"
                title="Ничего не найдено"
                description="Кажется здесь ничего нет"
            />
        );
    }

    return (
        <>
            <SearchInput
                placeholder="Поиск"
                iconName="search-normal"
                defaultValue={sessionSearchQuery}
                onSearch={handleSearch}
            />

            {filteredSession?.length ? (
                filteredSession.map((course) => (
                    <CourseContent
                        key={`${course.year}-${course.course}`}
                        course={course}
                    />
                ))
            ) : (
                <StateWidget
                    variant="transparent"
                    code="empty"
                    title="Ничего не найдено"
                    description={
                        sessionSearchQuery
                            ? 'Попробуйте изменить запрос'
                            : 'Кажется здесь ничего нет'
                    }
                />
            )}
        </>
    );
};