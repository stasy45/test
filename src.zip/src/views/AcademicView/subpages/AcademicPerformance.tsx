import {StateWidget} from "@/widgets";
import {useUnit} from "effector-react";
import {
    $academicPerf,
    $filteredAcademicPerf, $searchQuery,
    $serverErrorAcademicPerf,
    searchQueryChanged
} from "../model.ts";
import {Accordion, Separator, TableItem, Tag, Typography} from "@/components";
import {FC} from "react";
import {TYPOGRAPHY_COLOR_BY_STATUS} from "@/utils/maps.ts";
import {SearchInput} from "@/feature-components";
import {Course} from "@/api/students/models.ts";
import {router} from "@/store/router.ts";
import {useViewportInfo} from "@/hooks";
import {DEFAULT_BREAKPOINTS} from "@/utils/device-viewport.ts";


type Classes = Course["subjects"][number]["classes"];

type ClassesContentProps = {
    classes: Classes;
};

const ClassesContent: FC<ClassesContentProps> = ({classes}) => {
    const {isMobile} = useViewportInfo({mobile: DEFAULT_BREAKPOINTS.mobile});

    if (!classes.length) {
        return (
            <StateWidget
                variant="transparent"
                code="empty"
                title="Ничего не найдено"
                description="Кажется здесь ничего нет"
            />
        );
    }

    return (
        <>
            {classes.map((classItem, index) => {
                const isLast = index === classes.length - 1;

                return (
                    <div key={index} className={isMobile ? "flex-col" : "flex-row"}>
                        <TableItem
                            orientation="vertical"
                            bordered={!isMobile ? !isLast : true}
                            withLabel={!isMobile ? index === 0 : true}
                            label="Дата"
                        >
                            {classItem.date}
                        </TableItem>

                        <TableItem
                            orientation="vertical"
                            bordered={!isMobile ? !isLast : true}
                            withLabel={!isMobile ? index === 0 : true}
                            label="Тема"
                        >
                            {classItem.topic}
                        </TableItem>

                        <TableItem
                            orientation="vertical"
                            bordered={!isMobile ? !isLast : true}
                            withLabel={!isMobile ? index === 0 : true}
                            label="Тип занятия"
                        >
                            <Tag text={classItem.type}/>
                        </TableItem>

                        <TableItem
                            orientation="vertical"
                            bordered={!isMobile ? !isLast : true}
                            withLabel={!isMobile ? index === 0 : true}
                            label="Оценка"
                        >
                            <Tag
                                color={TYPOGRAPHY_COLOR_BY_STATUS[classItem.grade.type]}
                                text={classItem.grade.message}
                            />
                        </TableItem>

                        <TableItem
                            orientation="vertical"
                            bordered={!isLast}
                            withLabel={!isMobile ? index === 0 : true}
                            label="Посещаемость"
                        >
                            <Tag
                                color={TYPOGRAPHY_COLOR_BY_STATUS[classItem.attendance.type]}
                                text={classItem.attendance.message}
                            />
                        </TableItem>

                        {isMobile && !isLast && (
                            <Separator/>
                        )}
                    </div>
                );
            })}
        </>
    );
};


const SubjectContent: FC<{
        subject: Course["subjects"][number];
    }> = ({subject}) => {
        return (
            <Accordion>
                <Accordion.Header>
                    <Typography.h5>
                        {subject.name}
                    </Typography.h5>
                </Accordion.Header>

                <Accordion.Content>
                    <ClassesContent classes={subject.classes}/>
                </Accordion.Content>
            </Accordion>
        )
            ;
    }
;


const CourseContent: FC<{
    course: Course;
}> = ({course}) => {
    return (
        <Accordion>
            <Accordion.Header>
                <Typography.h4>
                    {course.year} / {course.course} курс
                </Typography.h4>
            </Accordion.Header>

            <Accordion.Content>
                {course.subjects.map((subject) => (
                    <SubjectContent
                        key={subject.name}
                        subject={subject}
                    />
                ))}
            </Accordion.Content>
        </Accordion>
    );
};


export const AcademicPerformancePage = () => {
    const [academicPerf, filteredAcademicPerf, searchQuery, serverError] = useUnit([
        $academicPerf,
        $filteredAcademicPerf,
        $searchQuery,
        $serverErrorAcademicPerf,
    ]);

    const handleSearch = useUnit(searchQueryChanged);

    if (serverError) {
        return (
            <StateWidget
                code={serverError?.status}
                title={serverError?.message}
                description={serverError?.description}
                button={serverError?.status === 403 && {
                    variant: 'ghost',
                    text: 'На главную',
                    icon: 'home',
                    onClick: () => router.navigate({to: '/', replace: true}),
                }}
            />
        );
    }

    if (!academicPerf || !academicPerf.length) {
        return (
            <StateWidget
                variant="transparent"
                code="empty"
                title="Ничего не найдено"
                description="Кажется здесь ничего нет"
            />
        );
    }

    return (
        <>
            <SearchInput
                placeholder="Поиск"
                iconName="search-normal"
                defaultValue={searchQuery}
                onSearch={handleSearch}
            />

            {filteredAcademicPerf?.length ? (
                filteredAcademicPerf.map((course) => (
                    <CourseContent
                        key={`${course.year}-${course.course}`}
                        course={course}
                    />
                ))
            ) : (
                <StateWidget
                    variant="transparent"
                    code="empty"
                    title="Ничего не найдено"
                    description={
                        searchQuery
                            ? 'Попробуйте изменить запрос'
                            : 'Кажется здесь ничего нет'
                    }
                />
            )}
        </>
    );
};