import {useGate, useUnit} from "effector-react";
import {
    TransitionSwitch, Typography,
} from "@/components";
import {Tabs} from "@/feature-components";
import {useRegisterDevPage} from "@/widgets";
import {
    $academicLoading,
    AcademicViewGate,
} from "./model.ts";
import {AcademicPerformancePage} from "@/views/AcademicView/subpages/AcademicPerformance.tsx";
import {SessionPage} from "@/views/AcademicView/subpages/Session.tsx";
import {router} from "@/store/router.ts";


export const AcademicView = () => {
    useRegisterDevPage("academic");
    useGate(AcademicViewGate);

    const [isLoading] = useUnit([
        $academicLoading
    ]);

    const searchParams = useUnit(router.$searchParams)

    return (
        <>
            <Typography.h2 fontColor="accent">{searchParams['group']}</Typography.h2>
            <Tabs paramName="tab">
                <Tabs.Button
                    slug="academic-performance"
                    label="Успеваемость"
                />

                <Tabs.Button
                    slug="session"
                    label="Сессия"
                />

                <Tabs.Content
                    slug="academic-performance"
                    className="flex-col gap-16"
                >
                    <TransitionSwitch
                        className="flex-col gap-16"
                        isLoading={isLoading}
                    >
                        <AcademicPerformancePage/>
                    </TransitionSwitch>
                </Tabs.Content>

                <Tabs.Content
                    slug="session"
                    className="flex-col gap-16"
                >
                    <SessionPage/>
                </Tabs.Content>
            </Tabs>
        </>
    );
};