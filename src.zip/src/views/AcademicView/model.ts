import {combine, createEffect, createEvent, createStore, sample} from 'effector';
import {createGate} from 'effector-react';
import {createServerErrorStore} from '@/shared/effector';
import {appDataRefreshRequested} from '@/store/app';
import {filterCoursesBySearch, filterSessionsBySearch} from './search.ts';
import {router} from "@/store/router.ts";
import {studentsService} from "@/api/students/service.ts";
import {Course, Session} from "@/api/students/models.ts";


export const AcademicViewGate = createGate();

const getAcademicPerformanceFx = createEffect(studentsService.getAcademicPerformance);
const getSessionFx = createEffect(studentsService.getSession);

export const $serverErrorAcademicPerf = createServerErrorStore(getAcademicPerformanceFx);
export const $serverErrorSession = createServerErrorStore([getSessionFx]);
export const $academicLoading = combine(
    getAcademicPerformanceFx.pending,
    getSessionFx.pending,
    (academicLoading, sessionLoading) =>
        academicLoading || sessionLoading,
);
export const $academicPerf = createStore<Course[] | null>(null).on(
    getAcademicPerformanceFx.doneData,
    (_, academicPerf) => academicPerf,
);
export const $session = createStore<Session[] | null>(null).on(
    getSessionFx.doneData,
    (_, session) => session,
);

export const searchQueryChanged = createEvent<string>();
export const $searchQuery = createStore('').on(
    searchQueryChanged,
    (_, query) => query,
);

export const $filteredAcademicPerf = combine(
    $academicPerf,
    $searchQuery,
    (academicPerf, searchQuery) => filterCoursesBySearch(academicPerf, searchQuery),
);

const $isAcademicReady = combine(
    AcademicViewGate.status,
    router.$searchParams,
    (isOpen, search) =>
        isOpen && search['studentId'] !== undefined && search['panel'] === 'academic',
);

sample({
    clock: $isAcademicReady,
    source: router.$searchParams,
    filter: (_, ready) => ready,
    fn: (search) => search['studentId'],
    target: [getAcademicPerformanceFx, getSessionFx],
});

sample({
    clock: appDataRefreshRequested,
    source: {gate: AcademicViewGate.status, search: router.$searchParams},
    filter: ({gate, search}) => gate && search['studentId'] !== undefined && search['panel'] === 'academic',
    fn: ({search}) => (search['studentId']),
    target: [getAcademicPerformanceFx, getSessionFx],
});

export const sessionSearchQueryChanged = createEvent<string>();
export const $sessionSearchQuery = createStore('').on(
    sessionSearchQueryChanged,
    (_, query) => query,
);

export const $filteredSession = combine(
    $session,
    $sessionSearchQuery,
    (session, sessionSearchQuery) => filterSessionsBySearch(session, sessionSearchQuery),
);

// сброс при уходе со страницы, как и для academicPerf
sample({
    clock: AcademicViewGate.close,
    fn: () => '',
    target: [$searchQuery, $sessionSearchQuery],
});