import {Course, Session} from "@/api/students/models.ts";


type Subject = Course['subjects'][number];
type Class = Subject['classes'][number];

type Semester = Session['semester'][number];
type SessionSubject = Semester['subjects'][number];

const normalize = (value: string) => value.trim().toLowerCase();

const matchesQuery = (value: string | number, query: string) =>
    String(value).toLowerCase().includes(query);

const filterClasses = (classes: Class[], query: string): Class[] =>
    classes.filter((classItem) => matchesQuery(classItem.topic, query));

const filterSubjects = (subjects: Subject[], query: string): Subject[] =>
    subjects.reduce<Subject[]>((acc, subject) => {
        // если совпала дисциплина — оставляем все её занятия как есть
        if (matchesQuery(subject.name, query)) {
            acc.push(subject);
            return acc;
        }

        // иначе ищем совпадения среди занятий внутри дисциплины
        const filteredClasses = filterClasses(subject.classes, query);
        if (filteredClasses.length) {
            acc.push({...subject, classes: filteredClasses});
        }

        return acc;
    }, []);

/** Фильтрует курсы по году, названию дисциплины и теме занятия */
export const filterCoursesBySearch = (
    courses: Course[] | null,
    rawQuery: string
): Course[] | null => {
    if (!courses) return courses;

    const query = normalize(rawQuery);
    if (!query) return courses;

    return courses.reduce<Course[]>((acc, course) => {
        // если совпал год — оставляем курс целиком, без дальнейшей фильтрации
        if (matchesQuery(course.year, query)) {
            acc.push(course);
            return acc;
        }

        const filteredSubjects = filterSubjects(course.subjects, query);
        if (filteredSubjects.length) {
            acc.push({...course, subjects: filteredSubjects});
        }

        return acc;
    }, []);
};

const filterSessionSubjects = (subjects: SessionSubject[], query: string): SessionSubject[] =>
    subjects.filter(
        (subject) => matchesQuery(subject.name, query) || matchesQuery(subject.type, query)
    );

const filterSemesters = (semesters: Semester[], query: string): Semester[] =>
    semesters.reduce<Semester[]>((acc, semester) => {
        // совпал номер семестра — оставляем все его дисциплины как есть
        if (matchesQuery(semester.count, query)) {
            acc.push(semester);
            return acc;
        }

        const filteredSubjects = filterSessionSubjects(semester.subjects, query);
        if (filteredSubjects.length) {
            acc.push({...semester, subjects: filteredSubjects});
        }

        return acc;
    }, []);

/** Фильтрует сессии по году, номеру семестра, дисциплине и форме контроля */
export const filterSessionsBySearch = (
    sessions: Session[] | null,
    rawQuery: string
): Session[] | null => {
    if (!sessions) return sessions;

    const query = normalize(rawQuery);
    if (!query) return sessions;

    return sessions.reduce<Session[]>((acc, session) => {
        // совпал год — оставляем сессию целиком
        if (matchesQuery(session.year, query)) {
            acc.push(session);
            return acc;
        }

        const filteredSemesters = filterSemesters(session.semester, query);
        if (filteredSemesters.length) {
            acc.push({...session, semester: filteredSemesters});
        }

        return acc;
    }, []);
};