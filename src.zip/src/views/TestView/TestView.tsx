import {InfoCard, Modal, TableItem, Tag} from "@/components";
import {PDFPreviewWidget} from "@/widgets";
import {useState} from "react";


export const TestView = () => {

    const [isModalOpen, setIsModalOpen] = useState(false);

    return (
        <>
            <button onClick={() => setIsModalOpen(true)}>
                Открыть модальное окно
            </button>

            <Modal
                isOpen={isModalOpen}
                onClose={() => setIsModalOpen(false)}
            >
                <p>Содержимое модального окна</p>
            </Modal>
        </>
    );
}