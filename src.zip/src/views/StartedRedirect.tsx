import React from 'react';
import {Navigate} from 'react-router-dom';
import {forkAccess} from "@/shared/auth/ForkAccess.tsx";


export const StartedRedirect = forkAccess({
    ACCESS_STUDENT_PROFILE: <Navigate to="student-profile" replace/>,
    VIEW_ALL_STUDENTS: <Navigate to="test" replace/>
});