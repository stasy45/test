import {createEffect, createStore, sample} from 'effector';
import {createGate} from 'effector-react';
import {createServerErrorStore} from '@/shared/effector';
import {appDataRefreshRequested} from '@/store/app';
import {router} from "@/store/router.ts";
import {studentsService} from "@/api/students/service.ts";
import {Payment} from "@/api/students/models.ts";


export const PaymentViewGate = createGate();

const getPaymentStepsFx = createEffect(studentsService.getPaymentSteps);

export const $serverError = createServerErrorStore(getPaymentStepsFx);
export const $paymentLoading = getPaymentStepsFx.pending;
export const $payment = createStore<Payment | null>(null).on(
    getPaymentStepsFx.doneData,
    (_, payment) => payment,
);

sample({
    clock: [PaymentViewGate.open, router.$searchParams],
    source: {search: router.$searchParams},
    filter: ({search}) => search['studentId'] !== undefined && search['panel'] === 'payments',
    fn: ({search}) => ({
        studentId: search['studentId'],
    }),
    target: getPaymentStepsFx,
});

sample({
    clock: appDataRefreshRequested,
    source: {gate: PaymentViewGate.status, search: router.$searchParams},
    filter: ({gate, search}) => gate && search['studentId'] !== undefined && search['panel'] === 'payments',
    fn: ({search}) => ({
        studentId: search['studentId'],
    }),
    target: getPaymentStepsFx,
});
