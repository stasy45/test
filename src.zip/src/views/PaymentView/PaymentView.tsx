import {PDFPreviewWidget, StateWidget, useRegisterDevPage} from "@/widgets";
import {useGate, useUnit} from "effector-react";
import {Button, Modal, Separator, TableItem, TransitionSwitch, Typography} from "@/components";
import {$payment, $paymentLoading, $serverError, PaymentViewGate} from "./model.ts";
import {useState} from "react";
import {Payment} from "@/api/students/models.ts";
import {router} from "@/store/router.ts";
import {useViewportInfo} from "@/hooks";
import {DEFAULT_BREAKPOINTS} from "@/utils/device-viewport.ts";
import cn from 'classnames';

type Steps = Payment['steps'];

const StepsContent = ({steps}: { steps: Steps }) => {
    const hasSteps = Boolean(steps?.length);

    // Храним индекс шага, для которого открыта модалка (null — закрыта)
    const [modalStepIndex, setModalStepIndex] = useState<number | null>(null);

    const {isMobile} = useViewportInfo({mobile: DEFAULT_BREAKPOINTS.mobile});

    return (
        <>
            {hasSteps ? (
                <>
                    {steps.map((step, index) => {
                        const isLast = index === steps.length - 1;
                        const isModalOpen = modalStepIndex === index;

                        return (
                            <div key={index} className={isMobile ? "flex-col" : "flex-row"}>
                                <div className={cn("d-flex", !isMobile ? "w-20" : "align-items-center")}>
                                    <TableItem
                                        orientation="vertical"
                                        bordered={!isMobile ? !isLast : true}
                                        withLabel={!isMobile ? index === 0 : true}
                                        label="Семестр"
                                    >
                                        {step.semester}
                                    </TableItem>
                                    {
                                        isMobile && step.checkURL &&
                                        <Button
                                            size="big"
                                            shape="square"
                                            variant="ghost"
                                            iconName="receipt"
                                            onClick={() => setModalStepIndex(index)}
                                        />
                                    }
                                </div>
                                <TableItem
                                    orientation="vertical"
                                    bordered={!isMobile ? !isLast : true}
                                    withLabel={!isMobile ? index === 0 : true}
                                    label="Курс"
                                    className={!isMobile && "w-20"}
                                >
                                    {step.course}
                                </TableItem>
                                <TableItem
                                    orientation="vertical"
                                    bordered={!isMobile ? !isLast : true}
                                    withLabel={!isMobile ? index === 0 : true}
                                    label="Крайний срок"
                                >
                                    {step.dueDate}
                                </TableItem>
                                <TableItem
                                    orientation="vertical"
                                    bordered={!isLast}
                                    withLabel={!isMobile ? index === 0 : true}
                                    label="Сумма"
                                    className={!isMobile && "w-30"}
                                >
                                    {step.amount}
                                </TableItem>
                                {!isMobile && (
                                    <TableItem
                                        orientation="vertical"
                                        bordered={!isLast}
                                        withLabel={index === 0}
                                        label="Счёт"
                                        className={!isMobile && "w-10"}
                                    >
                                        {
                                            step.checkURL &&
                                            <Button
                                                size="big"
                                                shape="square"
                                                variant="ghost"
                                                iconName="receipt"
                                                onClick={() => setModalStepIndex(index)}
                                            />
                                        }
                                    </TableItem>
                                )}
                                {isMobile && !isLast && (
                                    <Separator/>
                                )}

                                <Modal
                                    isOpen={isModalOpen}
                                    onClose={() => setModalStepIndex(null)}
                                >
                                    <Button
                                        variant="ghost"
                                        shape={!isMobile ? "square" : 'rect'}
                                        iconName="printer"
                                        text={isMobile ? "Печать" : null}
                                        className={!isMobile && "position-absolute pos-b-10 pos-r-10"}
                                    />

                                    <PDFPreviewWidget src={step.checkURL}/>
                                </Modal>
                            </div>
                        );
                    })}
                </>
            ) : (
                <StateWidget
                    variant="transparent"
                    code="empty"
                    title="Ничего не найдено"
                    description="Кажется здесь ничего нет"
                />
            )}
        </>
    );
};

export const PaymentView = () => {
    useRegisterDevPage('payment');
    useGate(PaymentViewGate);

    const [payment, isLoading] = useUnit([$payment, $paymentLoading]);
    const serverError = useUnit($serverError);

    return (
        <TransitionSwitch className="flex-col gap-16" isLoading={isLoading}>
            {!serverError && payment ? (
                <>
                    <Typography.h4>{payment.contract}</Typography.h4>
                    <StepsContent steps={payment.steps}/>
                </>
            ) : (
                <StateWidget
                    code={serverError?.status}
                    title={serverError?.message}
                    description={serverError?.description}
                    button={serverError?.status === 403 && {
                        variant: 'ghost',
                        text: 'На главную',
                        icon: 'home',
                        onClick: () => router.navigate({to: '/', replace: true}),
                    }}
                />
            )}
        </TransitionSwitch>
    );
};