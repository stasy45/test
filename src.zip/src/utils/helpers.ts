import {DependencyList, MutableRefObject, useEffect, useLayoutEffect, useRef} from 'react';
import {useUnmount} from "@/hooks";


export const isString = (value: unknown): value is string => typeof value === 'string';

export const isNumber = (value: unknown): value is number => isString(value) ? !Number.isNaN(Number(value)) : typeof value === 'number';

export const isBrowser = !!(
    typeof window !== 'undefined' &&
    window.document &&
    window.document.createElement
)


export const isFunction = (value: unknown): value is Function => typeof value === 'function';


export const getIndex = (_: never, index: number) => index;


type TargetValue<T> = T | undefined | null;

type TargetType = HTMLElement | Element | Window | Document;

export type BasicTarget<T extends TargetType = Element> =
    | (() => TargetValue<T>)
    | TargetValue<T>
    | MutableRefObject<TargetValue<T>>;

export function getTargetElement<T extends TargetType>(target: BasicTarget<T>, defaultElement?: T) {
    if (!isBrowser) {
        return undefined;
    }

    if (!target) {
        return defaultElement;
    }

    let targetElement: TargetValue<T>;

    if (isFunction(target)) {
        targetElement = target();
    } else if ('current' in target) {
        targetElement = target.current;
    } else {
        targetElement = target;
    }

    return targetElement;
}


export default function depsAreSame(oldDeps: DependencyList, deps: DependencyList): boolean {
    if (oldDeps === deps) return true;
    for (let i = 0; i < oldDeps.length; i++) {
        if (!Object.is(oldDeps[i], deps[i])) return false;
    }
    return true;
}


export const createEffectWithTarget = (useEffectType: typeof useEffect | typeof useLayoutEffect) => {
    /**
     *
     * @param effect
     * @param deps
     * @param target target should compare ref.current vs ref.current, dom vs dom, ()=>dom vs ()=>dom
     */
    const useEffectWithTarget = (
        effect: React.EffectCallback,
        deps: React.DependencyList,
        target: Target,
    ) => {
        const hasInitRef = useRef(false);

        const lastElementRef = useRef<(Element | null)[]>([]);
        const lastDepsRef = useRef<DependencyList>([]);

        const unLoadRef = useRef(undefined);

        useEffectType(() => {
            const targets = Array.isArray(target) ? target : [target];
            const els = targets.map((item) => getTargetElement(item));

            // init run
            if (!hasInitRef.current) {
                hasInitRef.current = true;
                lastElementRef.current = els;
                lastDepsRef.current = deps;

                unLoadRef.current = effect();
                return;
            }

            if (
                els.length !== lastElementRef.current.length ||
                !depsAreSame(els, lastElementRef.current) ||
                !depsAreSame(deps, lastDepsRef.current)
            ) {
                unLoadRef.current?.();

                lastElementRef.current = els;
                lastDepsRef.current = deps;
                unLoadRef.current = effect();
            }
        });

        useUnmount(() => {
            unLoadRef.current?.();
            // for react-refresh
            hasInitRef.current = false;
        });
    };

    return useEffectWithTarget;
}


export const useEffectWithTarget = createEffectWithTarget(useEffect);