import {getCookie, setCookie} from 'cookies-next';
import {isNumber, isString} from "@/utils/helpers.ts";

export const DEVICE_VIEWPORT_SIZE_COOKIE = 'device-viewport-size';

export type DeviceViewport = 'mobile' | 'tablet' | 'desktop';

export interface Breakpoints {
    mobile?: number,
    tablet?: number
}

export interface ViewportSize {
    width: number,
    height: number
}

export interface ViewportInfo extends ViewportSize {
    isMobile: boolean,
    isTablet: boolean,
    isDesktop: boolean,
    deviceType: DeviceViewport
}

export const isValidViewportSize = (value: unknown): value is ViewportSize => {
    const size = isString(value) ? parseCookieViewportSize(value) : value;

    return (
        typeof size === 'object' &&
        'width' in size &&
        isNumber(size.width) &&
        'height' in size &&
        isNumber(size.height)
    );
}

export const parseCookieViewportSize = (value: unknown): ViewportSize => {
    const defaultSize: ViewportSize = {width: Number.MIN_SAFE_INTEGER, height: Number.MIN_SAFE_INTEGER};

    try {
        if (typeof value === 'string') {

            const size = JSON.parse(decodeURIComponent(value));

            if (isValidViewportSize(size)) {
                return size;
            }
            return defaultSize;
        }
    } catch (e) {
    }

    return defaultSize;
}

export function setCookieViewportSize(value: ViewportSize) {
    const viewportSize = JSON.stringify(value);
    setCookie(DEVICE_VIEWPORT_SIZE_COOKIE, viewportSize, {maxAge: Number.MAX_SAFE_INTEGER});
}

export function getViewportSizeFromCookie() {
    const cookie = getCookie(DEVICE_VIEWPORT_SIZE_COOKIE);
    return parseCookieViewportSize(cookie);
}

// device-viewport.ts
export const DEFAULT_BREAKPOINTS: Required<Breakpoints> = {
    mobile: 768,
    tablet: 1194,
};

export const computeViewportInfo = (
    {width, height}: ViewportSize,
    breakpoints: Breakpoints = {},
): ViewportInfo => {
    const mobile = breakpoints.mobile ?? DEFAULT_BREAKPOINTS.mobile;
    const tablet = breakpoints.tablet ?? DEFAULT_BREAKPOINTS.tablet;

    const isMobile = width <= mobile;
    const isTablet = width > mobile && width <= tablet;
    const isDesktop = width > tablet;

    const deviceType: DeviceViewport = isDesktop ? 'desktop' : isTablet ? 'tablet' : 'mobile';

    return {width, height, deviceType, isMobile, isTablet, isDesktop};
};