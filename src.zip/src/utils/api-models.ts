export type StatusType = 'warning' | 'error' | 'success' | 'default';

export interface SystemStatus {
    type: StatusType;
    message: string;
}


export interface ServerError {
    status?: number;
    message: string;
    description?: string;
}