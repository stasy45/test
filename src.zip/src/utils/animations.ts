import {Variants} from "framer-motion";

export const mobileMenuUlAnimationVariants = {
    initial: {
        y: '-190%',
        transition: {
            delay: 0.5,
            staggerChildren: 0.07,
            delayChildren: 0.2
        }
    },
    animate: {
        y: 0,
        transition: {
            delay: 0.5,
            staggerChildren: 0.05,
            staggerDirection: -1
        }
    },
    exit: {
        y: '-190%',
        transition: {
            staggerChildren: 0.07,
            delayChildren: 0.2
        }
    },
};

export const mobileOverlayAnimationVariants: Variants = {
    initial: {
        clipPath: "circle(30px at right top)",
        transition: {
            delay: 0.1,
            type: "spring",
            stiffness: 400,
            damping: 40
        }
    },
    animate: (height = 1000) => ({
        clipPath: `circle(${height * 2 + 200}px at right top)`,
        transition: {
            delay: 0.1,
            type: "spring",
            stiffness: 20,
            restDelta: 2
        }
    }),
    exit: {
        clipPath: "circle(30px at right top)",
        transition: {
            delay: 0.05,
            type: "spring",
            stiffness: 400,
            damping: 40
        }
    }
}