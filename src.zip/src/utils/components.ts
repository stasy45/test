

export type ComponentSize = 'big' | 'medium' | 'small';
export type IconPosition = 'before' | 'after'; 

export type Orientation = 'horizontal' | 'vertical';

export type Option = {
    label: string;
    value: number;
};