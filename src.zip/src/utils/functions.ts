import {showNotify} from "@/shared/notifications/showNotify.tsx";


export const copyToClipboard = async (text: string) => {
    try {
        if (navigator.clipboard && window.isSecureContext) {
            await navigator.clipboard.writeText(text);
            showNotify({
                type: "success",
                title: "Текст успешно скопирован"
            })
        } else {
            // фолбэк для http/старых браузеров
            const textarea = document.createElement('textarea');
            textarea.value = text;
            textarea.style.position = 'fixed';
            textarea.style.opacity = '0';
            document.body.appendChild(textarea);
            textarea.focus();
            textarea.select();
            document.execCommand('copy');
            document.body.removeChild(textarea);

            showNotify({
                type: "success",
                title: "Текст успешно скопирован"
            })
        }
    } catch (error) {
        console.error('Не удалось скопировать текст', error);

        showNotify({
            type: "error",
            title: "Ошибка копирования"
        })
    }
};