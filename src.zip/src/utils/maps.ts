import {IconsNames} from "@/components";
import {StatusType} from "@/utils/api-models.ts";

export const TYPOGRAPHY_COLOR_BY_STATUS = {
    warning: 'yellow',
    error: 'red',
    success: 'green',
    default: 'secondary',
} as const satisfies Record<StatusType, 'yellow' | 'red' | 'green' | 'secondary'>;

export const ICON_BY_STATUS = {
    warning: 'danger',
    error: 'close-circle',
    success: 'tick-square',
    default: null,
} as const satisfies Record<StatusType, IconsNames>;