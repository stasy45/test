import {useEffect} from 'react';
import type {RefObject} from 'react';
import {useUnit} from 'effector-react';

import {compactHeaderHidden, compactHeaderShown} from '@/store/app';

/**
 * Следит за сентинел-элементом (нижней границей большой шапки).
 * Как только он уходит за пределы вьюпорта — включает компакт-шапку в сторе,
 * как только возвращается — выключает.
 *
 * enabled=false (например, на мобильном, где компакт-шапки нет вовсе)
 * отключает наблюдение полностью — обсёрвер не создаётся.
 */
export const useCompactHeaderObserver = (
    sentinelRef: RefObject<HTMLElement>,
    enabled = true,
) => {
    const [showHeader, hideHeader] = useUnit([compactHeaderShown, compactHeaderHidden]);

    useEffect(() => {
        if (!enabled) return;

        const node = sentinelRef.current;
        if (!node) return;

        const observer = new IntersectionObserver(
            ([entry]) => {
                if (entry.isIntersecting) {
                    hideHeader();
                } else {
                    showHeader();
                }
            },
            {threshold: 0},
        );

        observer.observe(node);

        return () => {
            observer.disconnect();
            hideHeader();
        };
    }, [sentinelRef, enabled, showHeader, hideHeader]);
};