import {FC, useLayoutEffect, useRef} from 'react';
import {Outlet, useLocation, useSearchParams} from 'react-router-dom';
import {useUnit} from 'effector-react';
import {Avatar, Button, GradientButton, Logo, MenuButton, TransitionSwitch, Typography} from '@/components';
import css from './MainLayout.module.scss';
import {AuthGuard} from '@/shared/auth/AuthGuard.tsx';
import {$appInfo, $appInfoLoading, $isCompactHeaderVisible, $serverError} from '@/store/app';
import {authModel} from '@/store/auth';
import {router} from '@/store/router';
import {StateWidget} from '@/widgets';
import {SideSheetLayout} from '@/layouts/SideSheetLayout';
import cn from "classnames";
import {MobileMenu} from "@/feature-components";
import {DEFAULT_BREAKPOINTS} from "@/utils/device-viewport.ts";
import {useViewportInfo} from "@/hooks";
import {useMobileMenuContext} from "@/feature-components/MobileMenu/context.ts";


export const MainLayout: FC = () => {
    const isLoading = useUnit($appInfoLoading);
    const serverError = useUnit($serverError);
    const [searchParams] = useSearchParams();

    const panelSlug = searchParams.get('panel');

    if (serverError) {
        return (
            <StateWidget
                code={serverError.status}
                title={serverError.message}
                description={serverError.description}
            />
        );
    }

    return (
        <AuthGuard>
            <MobileMenu>
                <TransitionSwitch isLoading={isLoading} className={css.container}>
                    <SideMenu/>
                    <Content/>

                    {panelSlug && <SideSheetLayout slug={panelSlug}/>}
                </TransitionSwitch>
            </MobileMenu>
        </AuthGuard>
    );
};

const Content = () => {
    const ref = useScrollReset();
    return (
        <main className={css.content} ref={ref}>
            <Header/>
            <div className={css.outlet}>
                <Outlet/>
            </div>
        </main>
    );
};

const SideMenu = () => {
    const appInfo = useUnit($appInfo);
    const {logout} = useUnit(authModel);
    const {isMobile} = useViewportInfo({mobile: DEFAULT_BREAKPOINTS.mobile});

    return (
        <MobileMenu.List className={css.side_bar}>
            <div className={css.items}>
                <Logo
                    className={css.logo}
                    variant={isMobile ? 'full' : 'small'}
                />

                <div className={css.items_menu}>
                    <MenuButton
                        to="student-profile"
                        iconName="profile"
                        label="Моя страница"
                        pattern={/^\/student-profile/}
                    />
                    <MenuButton
                        to="news"
                        iconName="document"
                        label="Новости"
                        pattern={/^\/news/}
                    />
                    <MenuButton
                        to="vacancy"
                        iconName="briefcase"
                        label="Вакансии"
                        pattern={/^\/vacancy/}
                    />
                    <MenuButton
                        to="https://is.samsmu.ru/lk-sa"
                        iconName="caduceus"
                        label="Аорта"
                        isExternal
                    />
                    <MenuButton
                        to="documents"
                        iconName="folder"
                        label="Мои документы"
                        pattern={/^\/documents/}
                    />
                    <MenuButton
                        to="inbox"
                        iconName="notification"
                        label="Входящие"
                        pattern={/^\/inbox/}
                        showBadge={appInfo?.income}
                    />
                </div>
            </div>

            <Button
                className="m-auto"
                iconName="logout"
                shape={isMobile ? "rect" : "square"}
                variant={isMobile ? "ghost" : "primary"}
                text={isMobile ? "Выход из аккаунта" : null}
                onClick={logout}
            />
        </MobileMenu.List>
    );
};

const Header = () => {
    const {isMobile} = useViewportInfo({mobile: DEFAULT_BREAKPOINTS.mobile});
    const currentUser = useUnit(authModel.currentUser);
    const {isOpen} = useMobileMenuContext();

    if (isMobile) {
        return (
            <div className={css.mobile_header}>
                <div className={cn(css.user_info, css.card)}>
                    <Avatar
                        size="small"
                        src={currentUser?.photo}
                        initials={currentUser?.initials}
                    />
                    <Typography.h6>{currentUser?.fio}</Typography.h6>
                </div>

                <div className={css.card}>
                    {!isOpen && <MobileMenu.Button/>}
                </div>
            </div>
        );
    }

    return <DesktopHeader/>;
};

const DesktopHeader = () => {
    const isVisible = useUnit($isCompactHeaderVisible);
    const currentUser = useUnit(authModel.currentUser);
    const appInfo = useUnit($appInfo);

    return (
        <div className={cn(css.header, {[css.visible]: isVisible})} aria-hidden={!isVisible}>
            <div className="gap-16 align-items-center">
                <Avatar size="small" src={currentUser?.photo} initials={currentUser?.initials}/>
                <Typography.h6>{currentUser?.fio}</Typography.h6>
            </div>
            {appInfo && !appInfo.isPassportActual && (
                <GradientButton
                    size="small"
                    isFull={false}
                    color="red"
                    iconName="warning-2"
                    text="Актуализируйте данные паспорта"
                    onClick={() => router.navigate({to: '/passport'})}
                />
            )}
        </div>
    );
};

const useScrollReset = () => {
    const {pathname} = useLocation();
    const ref = useRef<HTMLDivElement>(null);

    useLayoutEffect(() => {
        ref.current?.scrollTo({
            top: 0,
            left: 0,
            behavior: 'instant',
        });
    }, [pathname]);

    return ref;
};