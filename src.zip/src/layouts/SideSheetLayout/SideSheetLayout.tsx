import {FC} from 'react';
import {Button} from '@/components';
import {OverlayPortal, useCloseOnNavigate} from "@/feature-components";
import {useSlideTransition} from './useSlideTransition';
import css from './SideSheetLayout.module.scss';
import {PANELS} from './registry';

type SideSheetLayoutProps = {
    slug: string;
};

export const SideSheetLayout: FC<SideSheetLayoutProps> = ({slug}) => {
    const close = useCloseOnNavigate();
    const {isVisible, close: handleClose} = useSlideTransition(close);

    const panel = PANELS.find((panel) => panel.slug === slug);

    if (!panel) {
        return null;
    }

    return (
        <OverlayPortal>
            <div className={css.wrapper}>
                <div
                    className={css.overlay}
                    data-visible={isVisible}
                    onClick={handleClose}
                />

                <aside className={css.sideSheet} data-visible={isVisible}>
                    <Button
                        variant="ghost"
                        className={css.close_button}
                        shape="square"
                        onClick={handleClose}
                        iconName="close-circle"
                    />
                    {panel.render()}
                </aside>
            </div>
        </OverlayPortal>
    );
};