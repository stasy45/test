import {ReactNode} from 'react';
import {PaymentView} from "@/views/PaymentView";
import {AcademicView} from "@/views/AcademicView";
import {router} from "@/store/router.ts";
import {StateWidget} from "@/widgets";


export type PanelSlug = string;

type PanelDef = {
    slug: PanelSlug;
    render: () => ReactNode;
};

export const PANELS: PanelDef[] = [
    {
        slug: 'payments',
        render: () => <PaymentView/>,
    },
    {
        slug: 'academic',
        render: () => <AcademicView/>,
    },
    {
        slug: 'schedule',
        render: () => <StateWidget
            code="develop"
            variant="transparent"
            title="Ведутся работы"
            description="Страница в процессе разработки"
            button={{
                variant: 'ghost',
                text: 'На главную',
                icon: 'home',
                onClick: () => router.navigate({to: '/', replace: true}),
            }}
        />,
    },
];