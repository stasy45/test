import {useCallback, useEffect, useRef, useState} from 'react';

const DEFAULT_DURATION = 300;

const prefersReducedMotion = () =>
    window.matchMedia('(prefers-reduced-motion: reduce)').matches;

/**
 * Управляет фазами появления/скрытия для CSS-transition анимаций.
 * onClosed вызывается ПОСЛЕ завершения анимации выхода —
 * это позволяет размонтировать/убрать панель без визуального скачка.
 */
export const useSlideTransition = (onClosed: () => void, duration = DEFAULT_DURATION) => {
    const [isVisible, setIsVisible] = useState(false);
    const timeoutRef = useRef<number>(null);

    useEffect(() => {
        const frame = requestAnimationFrame(() => setIsVisible(true));

        return () => {
            cancelAnimationFrame(frame);
            window.clearTimeout(timeoutRef.current);
        };
    }, []);

    const close = useCallback(() => {
        const effectiveDuration = prefersReducedMotion() ? 0 : duration;

        setIsVisible(false);
        timeoutRef.current = window.setTimeout(onClosed, effectiveDuration);
    }, [duration, onClosed]);

    return {isVisible, close};
};