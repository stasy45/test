import "@/assets/styles/app.scss";
import {Router} from "./router/Router";
import {DevModeWidget} from "./widgets";
import {NotificationsContainer} from "./shared/notifications/NotificationContainer";


function App() {

    return (
        <>
            <Router/>
            <NotificationsContainer/>

            {import.meta.env.DEV && <DevModeWidget/>}
        </>
    )
}

export default App
