import {ComponentProps, FC, MouseEventHandler} from "react";

import cn from "classnames";

import {Button, Typography} from "@/components";

import error401 from "@/assets/illustrations/errors/error-401.png";
import error401Mobile from "@/assets/illustrations/errors/error-401_mobile.png";
import error403 from "@/assets/illustrations/errors/error-403.png";
import error403Mobile from "@/assets/illustrations/errors/error-403_mobile.png";
import error404 from "@/assets/illustrations/errors/error-404.png";
import error404Mobile from "@/assets/illustrations/errors/error-404_mobile.png";
import error500 from "@/assets/illustrations/errors/error-500.png";
import error500Mobile from "@/assets/illustrations/errors/error-500_mobile.png";
import empty from "@/assets/illustrations/errors/empty.png";
import develop from "@/assets/illustrations/errors/develop.png";

import css from "./StateWidget.module.scss";

type Illustration = {
    default: string;
    mobile: string;
};

const illustrations: Record<string, Illustration> = {
    "401": {default: error401, mobile: error401Mobile},
    "403": {default: error403, mobile: error403Mobile},
    "404": {default: error404, mobile: error404Mobile},
    "500": {default: error500, mobile: error500Mobile},
    "empty": {default: empty, mobile: null},
    "develop": {default: develop, mobile: null},
};

// Единая точка правды для брейкпоинта — совпадает с mxn.mobile768() в SCSS.
const MOBILE_BREAKPOINT_QUERY = "(max-width: 768px)";

type StateWidgetVariant = "card" | "transparent";

type ButtonProps = {
    variant?: ComponentProps<typeof Button>["variant"];
    icon?: ComponentProps<typeof Button>["iconName"];
    text?: string;
    onClick?: MouseEventHandler<HTMLButtonElement>;
    isLoading?: ComponentProps<typeof Button>["isLoading"];
};

interface StateWidgetProps {
    code: string | number;
    title: string;
    description?: string;
    variant?: StateWidgetVariant;
    button?: ButtonProps;
    className?: string;
}

export const StateWidget: FC<StateWidgetProps> = ({
                                                      code,
                                                      title,
                                                      description,
                                                      variant = "card",
                                                      button,
                                                      className,
                                                  }) => {
    const illustration = illustrations[String(code)];

    return (
        <div className={cn(css.container, css[variant], className)}>
            <div className={cn(css.content, css[variant])}>
                {illustration && (
                    <picture>
                        <source
                            media={MOBILE_BREAKPOINT_QUERY}
                            srcSet={illustration.mobile}
                        />
                        <img
                            className={css.illustration}
                            src={illustration.default}
                            alt=""
                        />
                    </picture>
                )}

                <div className="flex-col gap-8">
                    <Typography.h2 align="center" fontColor="accent">
                        {title}
                    </Typography.h2>

                    {description && (
                        <Typography.p1 align="center" fontColor="secondary">
                            {description}
                        </Typography.p1>
                    )}
                </div>

                {button && (
                    <Button
                        variant={button.variant ?? "ghost"}
                        size="big"
                        iconName={button.icon}
                        text={button.text}
                        onClick={button.onClick}
                        isLoading={button.isLoading}
                    />
                )}
            </div>
        </div>
    );
};