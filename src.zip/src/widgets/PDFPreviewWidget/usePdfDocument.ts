import {useEffect, useState} from 'react';
import * as pdfjsLib from 'pdfjs-dist';
import pdfWorker from 'pdfjs-dist/build/pdf.worker.min.mjs?url';


interface PdfDocumentState {
    document: pdfjsLib.PDFDocumentProxy | null;
    error: string | null;
}

pdfjsLib.GlobalWorkerOptions.workerSrc = pdfWorker;

export const usePdfDocument = (src: string) => {
    const [state, setState] = useState<PdfDocumentState>({
        document: null,
        error: null,
    });

    useEffect(() => {
        let cancelled = false;

        const loadingTask = pdfjsLib.getDocument({url: src});

        loadingTask.promise
            .then((document) => {
                if (cancelled) {
                    return;
                }

                setState({
                    document,
                    error: null,
                });
            })
            .catch((reason: unknown) => {
                if (cancelled) {
                    return;
                }

                setState({
                    document: null,
                    error:
                        reason instanceof Error
                            ? reason.message
                            : 'Не удалось загрузить PDF',
                });
            });

        return () => {
            cancelled = true;
            void loadingTask.destroy();
        };
    }, [src]);

    return {
        pdfDoc: state.document,
        error: state.error,
    };
};