import {useRef} from 'react';
import cn from 'classnames';

import {usePdfRenderer} from './usePdfRenderer';
import {usePdfDocument} from './usePdfDocument';
import {usePdfTransform} from './usePdfTransform';

import css from './PDFPreviewWidget.module.scss';
import {StateWidget} from '@/widgets';

export interface PDFPreviewWidgetProps {
    src: string;
    className?: string;
    renderScale?: number;
    minZoom?: number;
    maxZoom?: number;
}

const DEFAULT_RENDER_SCALE = 1.5;
const DEFAULT_MIN_ZOOM = 0.5;
const DEFAULT_MAX_ZOOM = 3;

export const PDFPreviewWidget = ({
                                     src,
                                     className,
                                     renderScale = DEFAULT_RENDER_SCALE,
                                     minZoom = DEFAULT_MIN_ZOOM,
                                     maxZoom = DEFAULT_MAX_ZOOM,
                                 }: PDFPreviewWidgetProps) => {
    const containerRef = useRef<HTMLDivElement>(null);
    const canvasRefs = useRef<(HTMLCanvasElement | null)[]>([]);

    const {pdfDoc, error} = usePdfDocument(src);

    usePdfRenderer({
        pdfDoc,
        getCanvas: (index) => canvasRefs.current[index],
        renderScale,
    });

    const {transform, handlers} = usePdfTransform({
        containerRef,
        minZoom,
        maxZoom,
    });

    const pageIndexes = pdfDoc
        ? Array.from({length: pdfDoc.numPages}, (_, index) => index)
        : [];

    if (error) {
        return (
            <StateWidget
                variant="transparent"
                code="empty"
                title="Не удалось отобразить файл"
            />
        );
    }

    return (
        <div
            ref={containerRef}
            className={cn(css.container, className)}
            {...handlers}
        >
            <div
                className={css.document}
                style={{
                    transform: `translate3d(${transform.x}px, ${transform.y}px, 0) scale(${transform.scale})`,
                }}
            >
                {pageIndexes.map((index) => (
                    <canvas
                        key={index}
                        ref={(element) => {
                            canvasRefs.current[index] = element;
                        }}
                        className={css.page}
                    />
                ))}
            </div>
        </div>
    );
};