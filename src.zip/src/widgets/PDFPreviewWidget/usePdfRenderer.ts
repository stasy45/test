import {useEffect} from 'react';
import type {PDFDocumentProxy} from 'pdfjs-dist';

interface UsePdfRendererParams {
    pdfDoc: PDFDocumentProxy | null;
    getCanvas: (index: number) => HTMLCanvasElement | null;
    renderScale: number;
}

export const usePdfRenderer = ({
                                   pdfDoc,
                                   getCanvas,
                                   renderScale,
                               }: UsePdfRendererParams) => {
    useEffect(() => {
        if (!pdfDoc) {
            return;
        }

        let cancelled = false;

        const render = async () => {
            for (
                let pageNumber = 1;
                pageNumber <= pdfDoc.numPages;
                pageNumber += 1
            ) {
                if (cancelled) {
                    return;
                }

                const canvas = getCanvas(pageNumber - 1);

                if (!canvas) {
                    continue;
                }

                const page = await pdfDoc.getPage(pageNumber);

                if (cancelled) {
                    page.cleanup();
                    return;
                }

                const viewport = page.getViewport({
                    scale: renderScale,
                });

                const context = canvas.getContext('2d');

                if (!context) {
                    page.cleanup();
                    continue;
                }

                canvas.width = viewport.width;
                canvas.height = viewport.height;

                await page.render({
                    canvas,
                    canvasContext: context,
                    viewport,
                }).promise;

                page.cleanup();
            }
        };

        void render();

        return () => {
            cancelled = true;
        };
    }, [pdfDoc, getCanvas, renderScale]);
};