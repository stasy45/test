import {
    useCallback,
    useEffect,
    useRef,
    useState,
    type MouseEvent as ReactMouseEvent,
    type PointerEvent as ReactPointerEvent,
    type RefObject,
} from 'react';

interface Transform {
    x: number;
    y: number;
    scale: number;
}

interface UsePdfTransformParams {
    containerRef: RefObject<HTMLDivElement | null>;
    minZoom: number;
    maxZoom: number;
}

interface PdfTransformHandlers {
    onPointerDown: (event: ReactPointerEvent<HTMLDivElement>) => void;
    onPointerMove: (event: ReactPointerEvent<HTMLDivElement>) => void;
    onPointerUp: (event: ReactPointerEvent<HTMLDivElement>) => void;
    onPointerCancel: (event: ReactPointerEvent<HTMLDivElement>) => void;
    onDoubleClick: (event: ReactMouseEvent<HTMLDivElement>) => void;
}

interface UsePdfTransformResult {
    transform: Transform;
    handlers: PdfTransformHandlers;
}

interface Point {
    x: number;
    y: number;
}

const INITIAL_TRANSFORM: Transform = {
    x: 0,
    y: 0,
    scale: 1,
};

const clamp = (value: number, min: number, max: number): number =>
    Math.min(Math.max(value, min), max);

const getDistance = (a: Point, b: Point): number =>
    Math.hypot(b.x - a.x, b.y - a.y);

const getCenter = (a: Point, b: Point): Point => ({
    x: (a.x + b.x) / 2,
    y: (a.y + b.y) / 2,
});

export const usePdfTransform = ({
                                    containerRef,
                                    minZoom,
                                    maxZoom,
                                }: UsePdfTransformParams): UsePdfTransformResult => {
    const [transform, setTransform] = useState<Transform>(
        INITIAL_TRANSFORM,
    );

    const transformRef = useRef<Transform>(INITIAL_TRANSFORM);

    const pointersRef = useRef<Map<number, Point>>(new Map());

    const dragRef = useRef<{
        startPoint: Point;
        startTransform: Transform;
    } | null>(null);

    const pinchRef = useRef<{
        startDistance: number;
        startCenter: Point;
        startTransform: Transform;
    } | null>(null);

    const updateTransform = useCallback((next: Transform) => {
        transformRef.current = next;
        setTransform(next);
    }, []);

    const getLocalPoint = useCallback(
        (clientX: number, clientY: number): Point => {
            const rect = containerRef.current?.getBoundingClientRect();

            if (!rect) {
                return {
                    x: clientX,
                    y: clientY,
                };
            }

            return {
                x: clientX - rect.left,
                y: clientY - rect.top,
            };
        },
        [containerRef],
    );

    const zoomAroundPoint = useCallback(
        (
            scale: number,
            point: Point,
            current: Transform,
        ): Transform => {
            const nextScale = clamp(scale, minZoom, maxZoom);
            const ratio = nextScale / current.scale;

            return {
                scale: nextScale,
                x: point.x - (point.x - current.x) * ratio,
                y: point.y - (point.y - current.y) * ratio,
            };
        },
        [minZoom, maxZoom],
    );

    useEffect(() => {
        const element = containerRef.current;

        if (!element) {
            return;
        }

        const handleWheel = (event: WheelEvent) => {
            event.preventDefault();

            const point = getLocalPoint(
                event.clientX,
                event.clientY,
            );

            const current = transformRef.current;

            const zoomFactor = Math.exp(-event.deltaY * 0.001);
            const nextScale = current.scale * zoomFactor;

            updateTransform(
                zoomAroundPoint(
                    nextScale,
                    point,
                    current,
                ),
            );
        };

        element.addEventListener('wheel', handleWheel, {
            passive: false,
        });

        return () => {
            element.removeEventListener('wheel', handleWheel);
        };
    }, [
        containerRef,
        getLocalPoint,
        updateTransform,
        zoomAroundPoint,
    ]);

    const onPointerDown = useCallback(
        (event: ReactPointerEvent<HTMLDivElement>) => {
            event.currentTarget.setPointerCapture(
                event.pointerId,
            );

            const point = getLocalPoint(
                event.clientX,
                event.clientY,
            );

            pointersRef.current.set(
                event.pointerId,
                point,
            );

            if (pointersRef.current.size === 1) {
                dragRef.current = {
                    startPoint: point,
                    startTransform: transformRef.current,
                };

                return;
            }

            if (pointersRef.current.size === 2) {
                const points = [
                    ...pointersRef.current.values(),
                ];

                const first = points[0];
                const second = points[1];

                if (!first || !second) {
                    return;
                }

                pinchRef.current = {
                    startDistance: getDistance(
                        first,
                        second,
                    ),
                    startCenter: getCenter(
                        first,
                        second,
                    ),
                    startTransform: transformRef.current,
                };

                dragRef.current = null;
            }
        },
        [getLocalPoint],
    );

    const onPointerMove = useCallback(
        (event: ReactPointerEvent<HTMLDivElement>) => {
            if (!pointersRef.current.has(event.pointerId)) {
                return;
            }

            const point = getLocalPoint(
                event.clientX,
                event.clientY,
            );

            pointersRef.current.set(
                event.pointerId,
                point,
            );

            if (
                pointersRef.current.size === 1 &&
                dragRef.current
            ) {
                const drag = dragRef.current;

                updateTransform({
                    ...drag.startTransform,
                    x:
                        drag.startTransform.x +
                        point.x -
                        drag.startPoint.x,
                    y:
                        drag.startTransform.y +
                        point.y -
                        drag.startPoint.y,
                });

                return;
            }

            if (
                pointersRef.current.size !== 2 ||
                !pinchRef.current
            ) {
                return;
            }

            const points = [
                ...pointersRef.current.values(),
            ];

            const first = points[0];
            const second = points[1];

            if (!first || !second) {
                return;
            }

            const pinch = pinchRef.current;

            const distance = getDistance(
                first,
                second,
            );

            if (pinch.startDistance === 0) {
                return;
            }

            const center = getCenter(
                first,
                second,
            );

            const scale =
                pinch.startTransform.scale *
                (distance / pinch.startDistance);

            const nextTransform = zoomAroundPoint(
                scale,
                pinch.startCenter,
                pinch.startTransform,
            );

            updateTransform({
                ...nextTransform,
                x:
                    nextTransform.x +
                    center.x -
                    pinch.startCenter.x,
                y:
                    nextTransform.y +
                    center.y -
                    pinch.startCenter.y,
            });
        },
        [
            getLocalPoint,
            updateTransform,
            zoomAroundPoint,
        ],
    );

    const endPointer = useCallback(
        (event: ReactPointerEvent<HTMLDivElement>) => {
            pointersRef.current.delete(
                event.pointerId,
            );

            if (
                event.currentTarget.hasPointerCapture(
                    event.pointerId,
                )
            ) {
                event.currentTarget.releasePointerCapture(
                    event.pointerId,
                );
            }

            if (pointersRef.current.size === 0) {
                dragRef.current = null;
                pinchRef.current = null;

                return;
            }

            if (pointersRef.current.size === 1) {
                const remainingPoint = [
                    ...pointersRef.current.values(),
                ][0];

                if (!remainingPoint) {
                    return;
                }

                dragRef.current = {
                    startPoint: remainingPoint,
                    startTransform: transformRef.current,
                };

                pinchRef.current = null;
            }
        },
        [],
    );

    const onDoubleClick = useCallback(
        (event: ReactMouseEvent<HTMLDivElement>) => {
            const point = getLocalPoint(
                event.clientX,
                event.clientY,
            );

            const current = transformRef.current;

            const nextScale =
                current.scale < (minZoom + maxZoom) / 2
                    ? maxZoom
                    : 1;

            updateTransform(
                zoomAroundPoint(
                    nextScale,
                    point,
                    current,
                ),
            );
        },
        [
            getLocalPoint,
            maxZoom,
            minZoom,
            updateTransform,
            zoomAroundPoint,
        ],
    );

    return {
        transform,
        handlers: {
            onPointerDown,
            onPointerMove,
            onPointerUp: endPointer,
            onPointerCancel: endPointer,
            onDoubleClick,
        },
    };
};