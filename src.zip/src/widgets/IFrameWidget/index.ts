export * from './IFrameWidget.tsx';
