import {useCallback, useEffect, useState, type FC} from 'react';

import {StateWidget} from '@/widgets';

import css from './IFrameWidget.module.scss';

export type LegacyPage = 'documents' | 'inbox' | 'passport' | 'news' | 'aorta';

interface LegacyPageViewProps {
    page: LegacyPage;
    title: string;
}

type ErrorCode = '401' | '403' | '404' | '500';

type LoadState =
    | { status: 'loading' }
    | { status: 'ready' }
    | { status: 'error'; code: ErrorCode };

const statusToCode = (status: number): ErrorCode => {
    if (status === 401) return '401';
    if (status === 403) return '403';
    if (status === 404) return '404';
    return '500';
};

const errorMeta: Record<ErrorCode, { title: string; description: string }> = {
    '401': {
        title: 'Необходима авторизация',
        description: 'Похоже, ваша сессия истекла. Войдите в систему заново',
    },
    '403': {
        title: 'Доступ запрещён',
        description: 'У вас недостаточно прав для просмотра этой страницы',
    },
    '404': {
        title: 'Страница не найдена',
        description: 'Запрошенный раздел не существует или был перемещён',
    },
    '500': {
        title: 'Не удалось загрузить страницу',
        description: 'Попробуйте обновить страницу ещё раз',
    },
};

/**
 * The frontend knows only stable semantic page names.
 * JSP names and legacy transport URLs are resolved by the BFF.
 */
export const IFrameWidget: FC<LegacyPageViewProps> = ({page, title}) => {
    const [reloadKey, setReloadKey] = useState(0);

    const handleRetry = useCallback(() => {
        setReloadKey((key) => key + 1);
    }, []);

    // key combines page+reloadKey so both a page switch and a manual retry
    // remount LegacyFrameContent, giving it a fresh 'loading' state without
    // resetting it via setState in an effect.
    return (
        <LegacyFrameContent
            key={`${page}-${reloadKey}`}
            page={page}
            title={title}
            onRetry={handleRetry}
        />
    );
};

interface LegacyFrameContentProps extends LegacyPageViewProps {
    onRetry: () => void;
}

const LegacyFrameContent: FC<LegacyFrameContentProps> = ({page, title, onRetry}) => {
    const [state, setState] = useState<LoadState>({status: 'loading'});
    const src = `/api/legacy/${page}`;

    useEffect(() => {
        const controller = new AbortController();

        // HTTP errors (401/403/404/500) still resolve as a "successful"
        // iframe load with an error body as content, so onError on the
        // <iframe> itself never fires for them — the status has to be
        // checked with a real fetch before we decide what to render.
        fetch(src, {signal: controller.signal})
            .then((response) => {
                setState(
                    response.ok
                        ? {status: 'ready'}
                        : {status: 'error', code: statusToCode(response.status)},
                );
            })
            .catch(() => {
                if (!controller.signal.aborted) {
                    setState({status: 'error', code: '500'});
                }
            });

        return () => controller.abort();
    }, [src]);

    if (state.status === 'error') {
        const {title: errorTitle, description} = errorMeta[state.code];

        return (
            <section className={css.container}>
                <StateWidget
                    code={state.code}
                    title={errorTitle}
                    description={description}
                    button={{
                        text: 'Повторить',
                        icon: 'refresh',
                        onClick: onRetry,
                    }}
                />
            </section>
        );
    }

    if (state.status === 'loading') {
        return <section className={css.container}/>;
    }

    return (
        <section className={css.container}>
            <iframe
                className={css.frame}
                src={src}
                title={title}
            />
        </section>
    );
};