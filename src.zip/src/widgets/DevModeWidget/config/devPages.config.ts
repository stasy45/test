import type {MockEndpointKey} from '@/shared/mocks/scenarios/registry';

import type {DevPageKey} from '@/widgets';

/**
 * Список эндпоинтов, которыми управляет dev-попап на конкретной странице.
 *
 * Чтобы добавить наполнение для новой страницы:
 *  1. добавьте её ключ в DevPageKey (model/activePage.model.ts);
 *  2. перечислите здесь релевантные ключи эндпоинтов из mocks/scenarios/registry.ts;
 *  3. вызовите useRegisterDevPage('newPageKey') внутри компонента страницы.
 */
export const devPagesConfig: Record<DevPageKey, MockEndpointKey[]> = {
    profile: ['getCurrentUser', 'getStudentProfile', 'getApplicationInfo'],
    payment: ['getPaymentSteps'],
    academic: ['getAcademicPerformance', 'getSession'],
};
