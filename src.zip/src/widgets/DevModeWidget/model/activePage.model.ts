import {createEvent, createStore} from 'effector';

/**
 * Ключи страниц, у которых есть собственное наполнение dev-виджета.
 * Добавляя новую страницу — расширьте этот union и devPages.config.ts.
 */
export type DevPageKey = 'profile' | 'payment' | 'academic';

export const devPageRegistered = createEvent<DevPageKey>();
export const devPageUnregistered = createEvent<DevPageKey>();

export const $activeDevPage = createStore<DevPageKey | null>(null)
    .on(devPageRegistered, (_, page) => page)
    .on(devPageUnregistered, (state, page) => (state === page ? null : state));
