import {createEffect, createEvent, createStore, sample} from 'effector';

import {appDataRefreshRequested} from '@/store/app';
import {syncMockWorker, type ApiSource} from '@/shared/mocks/browser';
import {
    persistApiSource,
    readPersistedApiSource,
} from '@/shared/mocks/persistence';

import {$selectedScenarios, type ScenarioSelection} from './scenarios.model';

export type {ApiSource};

export const apiSourceChanged = createEvent<ApiSource>();

export const $apiSource = createStore<ApiSource>(readPersistedApiSource()).on(
    apiSourceChanged,
    (_, apiSource) => apiSource,
);

const persistApiSourceFx = createEffect(persistApiSource);

sample({clock: apiSourceChanged, target: persistApiSourceFx});

/* ---------------- MSW sync ---------------- */

export const syncMockWorkerFx = createEffect<
    { apiSource: ApiSource; selection: ScenarioSelection },
    boolean
>(({apiSource, selection}) => syncMockWorker(apiSource, selection));

sample({
    clock: [apiSourceChanged, $selectedScenarios],
    source: {apiSource: $apiSource, selection: $selectedScenarios},
    target: syncMockWorkerFx,
});

sample({
    clock: syncMockWorkerFx.doneData,
    filter: (didSync) => didSync,
    target: appDataRefreshRequested,
});
