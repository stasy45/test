import {createEffect, createEvent, createStore, sample} from 'effector';

import type {ScenarioSelection} from '@/shared/mocks/handlers';
import {
    mockEndpoints,
    type MockEndpointKey,
} from '@/shared/mocks/scenarios/registry';
import {
    persistSelection,
    readPersistedSelection,
} from '@/shared/mocks/persistence';

export type {ScenarioSelection};

function buildDefaultSelection(): ScenarioSelection {
    return mockEndpoints.reduce((selection, endpoint) => {
        selection[endpoint.key as MockEndpointKey] = endpoint.defaultScenarioId;
        return selection;
    }, {} as ScenarioSelection);
}

export const scenarioSelected = createEvent<{
    endpointKey: MockEndpointKey;
    scenarioId: string;
}>();
export const scenariosReset = createEvent();

export const $selectedScenarios = createStore<ScenarioSelection>(
    readPersistedSelection(),
)
    .on(scenarioSelected, (state, {endpointKey, scenarioId}) => ({
        ...state,
        [endpointKey]: scenarioId,
    }))
    .on(scenariosReset, () => buildDefaultSelection());

const persistSelectionFx = createEffect(persistSelection);

sample({
    clock: [scenarioSelected, scenariosReset],
    source: $selectedScenarios,
    target: persistSelectionFx,
});
