# Dev Mode Widget

## Что это

Попап-виджет для разработки: переключает источник данных **backend ⇄ MSW**
и позволяет для каждого API-эндпоинта выбрать сценарий ответа (разные наборы данных и HTTP статус-коды). Каждая страница
объявляет свой набор эндпоинтов, которыми управляет попап — сейчас это страница профиля, новые страницы подключаются без
изменения самого виджета.

## Структура

```
shared/
  api/contracts/            — типы DTO по openapi-спеке (ApplicationInfo, CurrentUser, ProfileInfo…)
  mocks/
    scenarios/
      createScenario.ts     — типобезопасная фабрика сценариев
      *.scenarios.ts        — наборы сценариев на каждый эндпоинт (в т.ч. "дети: []" и т.п.)
      registry.ts           — единая точка регистрации эндпоинтов
    handlers.ts              — сборка msw handlers из текущего выбора сценариев
    browser.ts                — setupWorker + синхронизация с апи-сорсом

widgets/DevModeWidget/
  model/
    apiSource.model.ts       — стор backend/msw + эффект синка воркера
    scenarios.model.ts        — стор выбранных сценариев по ключам эндпоинтов
    activePage.model.ts        — какая страница сейчас активна
  config/devPages.config.ts   — маппинг "страница → эндпоинты, которые ей показывать"
  lib/useRegisterDevPage.ts    — хук, которым страница объявляет себя
  ui/
    DevModeWidget.tsx          — перетаскиваемый триггер + попап (framer-motion)
    DevPopup.tsx                — переключатель backend/msw + список сценариев
    EndpointScenarioControl.tsx — select конкретного эндпоинта + бейдж статус-кода
```

## Как добавить сценарий существующему эндпоинту

Откройте `shared/mocks/scenarios/<endpoint>.scenarios.ts` и добавьте ещё один
`createScenario({...})` — форма и статус будут типизированы по DTO эндпоинта. Ничего больше менять не нужно: попап и MSW
handlers подхватят его сами.

## Как добавить новый эндпоинт

1. Создайте `shared/mocks/scenarios/newEndpoint.scenarios.ts` по образцу соседних.
2. Зарегистрируйте его в `shared/mocks/scenarios/registry.ts`.
3. Добавьте ключ в список нужной страницы в `devPages.config.ts`.

## Как добавить новую страницу со своим набором сценариев

1. Добавьте ключ страницы в `DevPageKey` (`model/activePage.model.ts`).
2. Опишите список её эндпоинтов в `devPages.config.ts`.
3. В корневом компоненте страницы вызовите `useRegisterDevPage('key')`
   (см. `src/pages/ProfilePage.example.tsx`).

Пока ни одна страница не зарегистрирована, попап покажет заглушку с подсказкой, что нужно сделать.
