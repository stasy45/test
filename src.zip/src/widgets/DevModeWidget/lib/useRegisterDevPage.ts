import {useEffect} from 'react';
import {useUnit} from 'effector-react';

import {devPageRegistered, devPageUnregistered, type DevPageKey} from '../model/activePage.model';

/**
 * Регистрирует страницу для dev-виджета: пока страница смонтирована,
 * попап показывает только её набор сценариев (см. devPages.config.ts).
 *
 * Использование внутри компонента страницы:
 *
 *   export function ProfilePage() {
 *     useRegisterDevPage('profile');
 *     ...
 *   }
 */
export function useRegisterDevPage(page: DevPageKey): void {
    const [register, unregister] = useUnit([devPageRegistered, devPageUnregistered]);

    useEffect(() => {
        register(page);

        return () => {
            unregister(page);
        };
    }, [page, register, unregister]);
}
