import {useCallback, useEffect, useRef, type ChangeEvent} from 'react';
import {useUnit} from 'effector-react';

import {getMockEndpoint, type MockEndpointKey} from '@/shared/mocks/scenarios/registry';

import {devPagesConfig} from '../config/devPages.config';
import {$activeDevPage} from '../model/activePage.model';
import {$apiSource, apiSourceChanged, type ApiSource} from '../model/apiSource.model';
import {$selectedScenarios, scenarioSelected, scenariosReset} from '../model/scenarios.model';
import {EndpointScenarioControl} from './EndpointScenarioControl';

import css from './DevPopup.module.scss';

interface DevPopupProps {
    onClose: () => void;
}

export function DevPopup({onClose}: DevPopupProps) {
    const popupRef = useRef<HTMLDivElement>(null);

    const [apiSource, setApiSource, activePage, selectedScenarios, selectScenario, resetScenarios] = useUnit([
        $apiSource,
        apiSourceChanged,
        $activeDevPage,
        $selectedScenarios,
        scenarioSelected,
        scenariosReset,
    ]);

    useEffect(() => {
        function handlePointerDown(event: MouseEvent) {
            if (popupRef.current && !popupRef.current.contains(event.target as Node)) {
                onClose();
            }
        }

        function handleKeyDown(event: KeyboardEvent) {
            if (event.key === 'Escape') {
                onClose();
            }
        }

        document.addEventListener('mousedown', handlePointerDown);
        document.addEventListener('keydown', handleKeyDown);

        return () => {
            document.removeEventListener('mousedown', handlePointerDown);
            document.removeEventListener('keydown', handleKeyDown);
        };
    }, [onClose]);

    const handleSourceChange = useCallback(
        (event: ChangeEvent<HTMLInputElement>) => {
            const nextSource: ApiSource = event.target.checked ? 'msw' : 'backend';
            setApiSource(nextSource);
        },
        [setApiSource],
    );

    const handleScenarioChange = useCallback(
        (endpointKey: MockEndpointKey) => (scenarioId: string) => {
            selectScenario({endpointKey, scenarioId});
        },
        [selectScenario],
    );

    const endpointKeys = activePage ? devPagesConfig[activePage] : [];
    const isMswSourceActive = apiSource === 'msw';

    return (
        <div ref={popupRef} className={css.popup} role="dialog" aria-label="Настройки dev-режима">
            <header className={css.header}>
                <div className={css.headerTop}>
                    <span className={css.headerTitle}>Источник данных</span>
                    <span className={css.pageBadge}>{activePage ?? 'страница не зарегистрирована'}</span>
                </div>

                <label className={css.sourceSwitch}>
                    <span
                        className={!isMswSourceActive ? css.sourceSwitchLabelActive : css.sourceSwitchLabel}>Backend</span>

                    <span className={css.sourceSwitchControl}>
            <input
                type="checkbox"
                className={css.sourceSwitchInput}
                checked={isMswSourceActive}
                onChange={handleSourceChange}
            />
            <span className={css.sourceSwitchTrack} aria-hidden="true">
              <span className={css.sourceSwitchThumb}/>
            </span>
          </span>

                    <span className={isMswSourceActive ? css.sourceSwitchLabelActive : css.sourceSwitchLabel}>MSW</span>
                </label>
            </header>

            <div className={css.body} data-disabled={!isMswSourceActive || undefined}>
                {endpointKeys.length === 0 && (
                    <p className={css.emptyState}>
                        Эта страница ещё не зарегистрировала сценарии. Добавьте вызов
                        useRegisterDevPage(&apos;key&apos;) на
                        странице и её конфиг в devPages.config.ts.
                    </p>
                )}

                {endpointKeys.map((endpointKey) => {
                    const endpoint = getMockEndpoint(endpointKey);

                    return (
                        <EndpointScenarioControl
                            key={endpointKey}
                            endpoint={endpoint}
                            selectedScenarioId={selectedScenarios[endpointKey]}
                            onChange={handleScenarioChange(endpointKey)}
                        />
                    );
                })}
            </div>

            <footer className={css.footer}>
                <button type="button" className={css.resetButton} onClick={() => resetScenarios()}>
                    Сбросить сценарии к дефолтным
                </button>
            </footer>
        </div>
    );
}
