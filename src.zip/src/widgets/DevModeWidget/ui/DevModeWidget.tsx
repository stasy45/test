import {useCallback, useRef, useState} from 'react';
import {AnimatePresence, motion, useDragControls} from 'framer-motion';
import {useUnit} from 'effector-react';

import {$apiSource} from '../model/apiSource.model';
import {DevPopup} from './DevPopup';

import css from './DevModeWidget.module.scss';

const PANEL_TRANSITION = {
    type: 'spring',
    stiffness: 420,
    damping: 30,
    mass: 0.8,
} as const;

export function DevModeWidget() {
    const apiSource = useUnit($apiSource);
    const [isOpen, setIsOpen] = useState(false);

    const constraintsRef = useRef<HTMLDivElement>(null);
    const dragControls = useDragControls();

    const toggleOpen = useCallback(() => setIsOpen((prev) => !prev), []);
    const close = useCallback(() => setIsOpen(false), []);

    if (!import.meta.env.DEV) {
        return null;
    }

    return (
        <div ref={constraintsRef} className={css.viewport}>
            <motion.div
                drag
                dragControls={dragControls}
                dragListener={false}
                dragConstraints={constraintsRef}
                dragElastic={0.08}
                dragMomentum={false}
                className={css.widget}
                initial={{opacity: 0, scale: 0.92}}
                animate={{opacity: 1, scale: 1}}
                transition={PANEL_TRANSITION}
            >
                <button
                    type="button"
                    className={css.dragHandle}
                    aria-label="Перетащить dev-панель"
                    onPointerDown={(event) => dragControls.start(event)}
                >
                    ⠿
                </button>

                <button
                    type="button"
                    className={css.trigger}
                    onClick={toggleOpen}
                    aria-expanded={isOpen}
                    aria-label="Открыть настройки dev-режима"
                >
                    <span className={css.title}>DEV</span>
                    <span className={css.sourceBadge} data-source={apiSource}>
            {apiSource === 'msw' ? 'MSW' : 'API'}
          </span>
                </button>

                <div className={css.popupAnchor}>
                    <AnimatePresence>
                        {isOpen && (
                            <motion.div
                                initial={{opacity: 0, y: -8, scale: 0.96}}
                                animate={{opacity: 1, y: 0, scale: 1}}
                                exit={{opacity: 0, y: -8, scale: 0.96}}
                                transition={PANEL_TRANSITION}
                                className={css.popupPositioner}
                            >
                                <DevPopup onClose={close}/>
                            </motion.div>
                        )}
                    </AnimatePresence>
                </div>
            </motion.div>
        </div>
    );
}
