import {useId} from 'react';

import type {MockEndpointConfig} from '@/shared/mocks/scenarios/registry';

import css from './EndpointScenarioControl.module.scss';

interface EndpointScenarioControlProps {
    endpoint: MockEndpointConfig;
    selectedScenarioId: string;
    onChange: (scenarioId: string) => void;
}

export function EndpointScenarioControl({endpoint, selectedScenarioId, onChange}: EndpointScenarioControlProps) {
    const selectId = useId();
    const activeScenario = endpoint.scenarios.find((scenario) => scenario.id === selectedScenarioId);

    return (
        <div className={css.control}>
            <div className={css.meta}>
                <label htmlFor={selectId} className={css.label}>
                    {endpoint.label}
                </label>
                <span className={css.route}>
          {endpoint.method.toUpperCase()} {endpoint.url}
        </span>
            </div>

            <div className={css.selectRow}>
                <select
                    id={selectId}
                    className={css.select}
                    value={selectedScenarioId}
                    onChange={(event) => onChange(event.target.value)}
                >
                    {endpoint.scenarios.map((scenario) => (
                        <option key={scenario.id} value={scenario.id}>
                            {scenario.label}
                        </option>
                    ))}
                </select>

                {activeScenario && (
                    <span className={css.statusBadge} data-status-group={Math.floor(activeScenario.status / 100)}>
            {activeScenario.status}
          </span>
                )}
            </div>
        </div>
    );
}
