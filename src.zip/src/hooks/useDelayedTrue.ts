import { useEffect, useState } from 'react';

/**
 * Возвращает true только если value остаётся true дольше delay мс.
 * Если value становится false до истечения delay, возвращается false.
 */
export function useDelayedTrue(value: boolean, delay: number): boolean {
    const [delayedValue, setDelayedValue] = useState(false);

    useEffect(() => {
        if (value) {
            // Если value стало true, ждём delay
            const timer = setTimeout(() => {
                setDelayedValue(true);
            }, delay);

            return () => clearTimeout(timer);
        } else {
            // Если value стало false, сразу сбрасываем
            setDelayedValue(false);
        }
    }, [value, delay]);

    return delayedValue;
}