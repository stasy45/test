import {useLatest} from '@/hooks';
import {BasicTarget, getTargetElement, useEffectWithTarget} from "@/utils/helpers.ts";

type noop = (...p: unknown[]) => void;

type TargetElement = HTMLElement | Element | Window | Document;
export type Target = BasicTarget<TargetElement>;

type Options<T extends Target = Target> = {
    target?: T;
    capture?: boolean;
    once?: boolean;
    passive?: boolean;
    enabled?: boolean
};

function useEventListener<K extends keyof HTMLElementEventMap>(
    eventName: K,
    handler: (ev: HTMLElementEventMap[K]) => void,
    options?: Options<HTMLElement>,
): void;
function useEventListener<K extends keyof ElementEventMap>(
    eventName: K,
    handler: (ev: ElementEventMap[K]) => void,
    options?: Options<Element>,
): void;
function useEventListener<K extends keyof DocumentEventMap>(
    eventName: K,
    handler: (ev: DocumentEventMap[K]) => void,
    options?: Options<Document>,
): void;
function useEventListener<K extends keyof WindowEventMap>(
    eventName: K,
    handler: (ev: WindowEventMap[K]) => void,
    options?: Options<Window>,
): void;
function useEventListener(eventName: string, handler: noop, options: Options): void;

function useEventListener(eventName: string, handler: noop, options: Options = {}) {
    const handlerRef = useLatest(handler);

    useEffectWithTarget(
        () => {
            if (options.enabled === false) return;

            const targetElement = getTargetElement<TargetElement>(options.target, window);
            if (!targetElement?.addEventListener) {
                return;
            }

            const eventListener = (event: Event) => {
                return handlerRef.current(event);
            };

            targetElement.addEventListener(eventName, eventListener, {
                capture: options.capture,
                once: options.once,
                passive: options.passive,
            });

            return () => {
                targetElement.removeEventListener(eventName, eventListener, {
                    capture: options.capture,
                });
            };
        },
        [eventName, options.capture, options.once, options.passive, options.enabled],
        options.target,
    );
}

export {useEventListener};