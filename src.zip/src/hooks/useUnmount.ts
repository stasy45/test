import {useEffect} from 'react';
import {useLatest} from '@/hooks';

export const useUnmount = (callback: () => void) => {
    const fnRef = useLatest(callback);

    useEffect(() => () => {
            fnRef.current();
        },
        [],
    );
};