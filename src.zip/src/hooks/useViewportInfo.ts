import {useState} from 'react';
import {useEventListener} from '@/hooks';
import {isBrowser} from "@/utils/helpers.ts";
import {
    Breakpoints,
    computeViewportInfo,
    getViewportSizeFromCookie,
    setCookieViewportSize,
    ViewportInfo
} from "@/utils/device-viewport.ts";

export const useViewportInfo = (breakpoints?: Breakpoints) => {

    function getViewPortInfo(breakpoints?: Breakpoints, current?: ViewportInfo) {
        if (isBrowser) {
            const {
                innerWidth: width,
                innerHeight: height
            } = window;

            if (current?.width !== width || current?.height !== height) {
                setCookieViewportSize({
                    width,
                    height
                });
                const info = computeViewportInfo({
                    width,
                    height
                }, breakpoints);

                return {
                    width,
                    height, ...info
                }
            }

            return current;
        }

        const viewportSize = getViewportSizeFromCookie();
        return computeViewportInfo(viewportSize, breakpoints);
    }

    const [info, setViewportInfo] = useState(() => getViewPortInfo(breakpoints));

    const target = isBrowser ? window : undefined;
    useEventListener('resize',
        () => setViewportInfo(getViewPortInfo(breakpoints, info)),
        {target}
    );

    return info;
}